#include "../h/Thread.hpp"
extern  "C" void interruptvec();
#include "../h/Console.hpp"
void fja4(void* v){

    printString("CETVRTA NIT!\n");
    Thread::sleep(100);
    printString("CETVRTA NIT!\n");
    Thread::dispatch();

}
void fja1(void* v) {
    while(1) {
        printString("PRVA NIT!\n");
        //Thread::dispatch();
        Thread::sleep(2);
        printString("PRVA NIT!\n");
    }
}
void fja2(void *v){
    printString("DRUGA NIT!\n");
    Thread* t4=new Thread(fja4,nullptr);
    Thread::dispatch();
    Thread::sleep(20);
    printString("DRUGA NIT!\n");
    delete t4;

}
void fja3(void* v){
    printString("TRECA NIT!\n");
    Thread::sleep(10);
    printString("TRECA NIT!\n");
}


class Niti:public Thread{
public:
    Niti(int i):Thread(fja2,nullptr){br=i;printString("Nit broj: ");
        printInteger(br);}


private:
    int br;
};
/*void userMain(void* v){

    PeriodicThread* p=new PeriodicThread(10);
    PeriodicThread* p1=new PeriodicThread(15);
    PeriodicThread* p2=new PeriodicThread(20);
    char c;
    while((c=getc())!='k'){}
    delete p;
    delete p1;
    delete p2;
    printString("USER NIT ZAVRSILA!\n");
}*/
/*#include "../src/Buffer.hpp"
Buffer *buf=nullptr;
int brojac=0;
void proizv(void* v){
    int i=0;
    while(i<100){
        printString("\nProizvodjac\n");
        char c=Console::getc();
        buf->put(c);
        i++;
    }

}
void potr(void* v){
    int* idd=(int*)v;
    int id=*idd;

    int i=0;
    while(i<50){
        printString("\nPotrosac br. ");
        printInteger(id);
        printString("\n");
        char c=buf->get(id);
        char *ptr=&c;
        ptr[1]='\0';
        printString(&c);
        brojac++;
        i++;
    }
}
void userMain(void* a){

    if(buf==nullptr)buf=new Buffer();
    Thread *producer=new Thread(proizv,nullptr);
    int i=1;
    Thread *consumer1=new Thread(potr,&i);
    int j=2;
    Thread *consumer2=new Thread(potr,&j);
    //printString("doslo dovde");
    Thread::dispatch();

    delete producer;
    delete consumer1;
    delete consumer2;
    delete buf;

}*/
//#include "../h/Threads_C_API_test.hpp" // zadatak 2, niti C API i sinhrona promena konteksta
//#include "../h/Threads_CPP_API_test.hpp" // zadatak 2., niti CPP API i sinhrona promena konteksta

//#include "../h/ConsumerProducer_C_API_test.h" // zadatak 3., kompletan C API sa semaforima, sinhrona promena konteksta
//#include "../h/ConsumerProducer_CPP_Sync_API_test.hpp" // zadatak 3., kompletan CPP API sa semaforima, sinhrona promena konteksta

//#include "../h/ThreadSleep_C_API_test.hpp" // thread_sleep test C API
#include "../h/ConsumerProducer_CPP_API_test.hpp" // zadatak 4. CPP API i asinhrona promena konteksta

void userMain(void* arg) {
      //Threads_C_API_test(); // zadatak 2., niti C API i sinhrona promena konteksta
     //Threads_CPP_API_test(); // zadatak 2., niti CPP API i sinhrona promena konteksta

     //producerConsumer_C_API(); // zadatak 3., kompletan C API sa semaforima, sinhrona promena konteksta
     //producerConsumer_CPP_Sync_API(); // zadatak 3., kompletan CPP API sa semaforima, sinhrona promena konteksta

     //testSleeping(); // thread_sleep test C API
     ConsumerProducerCPP::testConsumerProducer(); // zadatak 4. CPP API i asinhrona promena konteksta, kompletan test svega
}


int main() {

    asm volatile("csrw stvec,%0" : : "r" (&interruptvec)); //jedinstvena prekidna rutina na koju skacem
    Thread* korisnickaNit=new Thread(userMain ,nullptr);
    promjeniRezim2();//da se vrati u korisnicki
    delete korisnickaNit;
    promjeniRezim();//da se vrati u sistemski na kraju


    return 0;
}

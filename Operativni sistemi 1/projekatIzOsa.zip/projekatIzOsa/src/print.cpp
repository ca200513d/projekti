#include "../lib/console.h"
#include "../h/print.hpp"
#include "../h/Console.hpp"
#define LOCK() {swap(0, 1);}
#define UNLOCK() {swap( 1, 0);}
void printString(const char *string){
    //LOCK();
    while(*string !='\0'){
        __putc(*string);
        string++;
    }
    //UNLOCK();
}

extern "C" void printInteger(uint64 integer){
   // LOCK();
    static char digits[]="0123456789";
    char buf[16];
    int i,neg;
    uint x;

    neg=0;
    if(integer<0){
        neg=1;
        x=-integer;
    }
    else{
        x=integer;
    }
    i=0;
    do{
        buf[i++]=digits[x%10];

    }
    while((x/=10)!=0);
    if(neg){
        buf[i++]='-';
    }
    while(--i>=0){
        __putc(buf[i]);
    }
   // UNLOCK();

}
void swap(int prvi,int drugi){
    if(prvi==0 && drugi==1){
        promjeniRezim();
    }
    else if(prvi==1 && drugi==0){
        promjeniRezim2();
    }
}
char* getString(){
    char* string=new char;
    char c;
    int i=0;
    while((c=Console::getc())!='\n'){
        string[i++]=c;
    }
    return string;
}

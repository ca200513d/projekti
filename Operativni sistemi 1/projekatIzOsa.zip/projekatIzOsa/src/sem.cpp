#include "../h/_sem.hpp"

extern "C" int sem_open1(sem_t* handle,unsigned init){
    return _sem::semOpen(handle,init);
}
extern "C" int sem_close1(sem_t handle){
    int ret=-1;
    if(handle!=nullptr)ret=_sem::semClose(handle);
    return ret;
}
extern "C" int sem_wait1(sem_t handle){
    int ret=-1;
    if(handle!=nullptr)ret=handle->semWait();
    return ret;
}
extern "C" int sem_signal1(sem_t handle){
    int ret=-1;
    if(handle!=nullptr)ret=handle->semSignal();
    return ret;
}
extern "C" int time_sleep1(unsigned long time){
    return _sem::timeSleep(time);
}


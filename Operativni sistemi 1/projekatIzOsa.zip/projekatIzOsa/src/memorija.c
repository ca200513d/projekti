#include "../lib/console.h"
#include "../lib/hw.h"
#define nullptr 0
#define false 0
#define true 1

static long *niz=nullptr; //niz koji sadrzi elemenata koliko je blokova, i svaki element odg.1 bloku

static long VAL=0; //broj elemenata u nizu


//provjera da li se od bloka iza elem.ind nalazi dovoljno slobodnih blokova
int isEmpty(long ind,long blocks){
    if(ind+blocks-1>=VAL)return false;
    for(long i=ind;i<blocks;i++){
        if(niz[i]!=-1){
            return false;
        }
    }
    return true;

}

//niz je oblika(1.zauzeti elem. sadrzi broj zauzetih elemenata,a ostali zauzeti u istom pozivu sadrze indeks 1.)
void* kernel_memalloc(size_t size){
    if(niz==nullptr){

        niz=(long*)HEAP_END_ADDR-(((long)HEAP_END_ADDR-(long)HEAP_START_ADDR)/(MEM_BLOCK_SIZE+sizeof(long)));
        for(long i=0;i<((long)HEAP_END_ADDR-(long)HEAP_START_ADDR)/(MEM_BLOCK_SIZE+sizeof(long));i++){
            niz[i]=-1;
        }
    }
    if(!VAL)VAL=((long)HEAP_END_ADDR-(long)HEAP_START_ADDR)/(MEM_BLOCK_SIZE+sizeof(long));
    if(size>=VAL || size<=0)return nullptr;
    long i=0;
    while(i<VAL){
        if(niz[i]!=-1){
            i+=niz[i];
        }
        else if(isEmpty(i,(long)size)==true){
            niz[i]=(long)size;
            for(long j=i+1;j<niz[i]+i;j++){
                niz[j]=i;
            }
            return (void*)HEAP_START_ADDR+i*MEM_BLOCK_SIZE;
        }
       else{
           i+=size;//jer ima praznog mjesta,ali ne koliko nam treba,pa trazimo dalje

       }
    }
    return nullptr;
}

//fja za dobijanje indeksa u nizu od adrese
long hash(void *addr){
    long adr=(long)addr;
    return (adr-(long)HEAP_START_ADDR)/(long)MEM_BLOCK_SIZE;
}

//memfree,upisuje 0 na indekse u nizu,koje odg blokovima koji se trebaju osloboditi
int kernel_memfree(void* addr){
    if(addr==nullptr)return -1;
    if(addr<HEAP_START_ADDR && addr>HEAP_END_ADDR)return -2;
    long ind=hash(addr);

    if(ind<0)return -3;
    if(niz[ind]==-1)return -4;
    long kol=niz[ind]-1;
    niz[ind++]=-1;
    for(long i=ind;i<kol;i++){
        niz[i]=-1;
    }
    return 0;
}
/*
int main(){
    char* c1=kernel_memalloc(5);
    char* c2=kernel_memalloc(20);
    char* c3=kernel_memalloc(45);
    char* c4=kernel_memalloc(1);
    int* c5=kernel_memalloc(0);

    if(c5==nullptr){
        __putc('G');
        __putc('R');
        __putc('E');
        __putc('S');
        __putc('K');
        __putc('A');
        __putc(' ');
        __putc('v');
        __putc('e');
        __putc('l');
        __putc(' ');
        __putc('0');
        __putc('\n');
    }

    c4[0]='a';
    c1[0]='a';
    for(int i=1;i<5;i++){
        c1[i]=c1[i-1]+1;
    }
    for(int i=0;i<5;i++){
        __putc(c1[i]);
    }
    __putc('\n');
    c2[0]='a';
    for(int i=1;i<20;i++){
        c2[i]=c2[i-1]+1;
    }
    for(int i=0;i<20;i++){
        __putc(c2[i]);
    }
    __putc('\n');
    for(int i=0;i<5;i++){
        __putc(c1[i]);
    }
    for(int i=0;i<45;i++){
        c3[i]=(char)i;
    }
    __putc('\n');
    for(int i=0;i<45;i++){
        __putc((int)c3[i]);
    }
    __putc('\n');
    for(int i=0;i<5;i++){
        __putc(c1[i]);
    }
    __putc('\n');
    for(int i=0;i<20;i++){
        __putc(c2[i]);
    }
    __putc('\n');
    int n;
     n=kernel_memfree(c1);
     if(n!=0){
         __putc('G');
         __putc('R');
         __putc('E');
         __putc('S');
         __putc('K');
         __putc('A');
         __putc(' ');
         __putc('d');
         __putc('e');
         __putc('a');
         __putc('l');
         __putc('l');
         __putc('o');
         __putc('c');
         __putc('\n');
     }
     n=kernel_memfree(c3);
    if(n!=0){
        __putc('G');
        __putc('R');
        __putc('E');
        __putc('S');
        __putc('K');
        __putc('A');
        __putc(' ');
        __putc('d');
        __putc('e');
        __putc('a');
        __putc('l');
        __putc('l');
        __putc('o');
        __putc('c');
        __putc('\n');
    }
     n=kernel_memfree(c2);
    if(n!=0){
        __putc('G');
        __putc('R');
        __putc('E');
        __putc('S');
        __putc('K');
        __putc('A');
        __putc(' ');
        __putc('d');
        __putc('e');
        __putc('a');
        __putc('l');
        __putc('l');
        __putc('o');
        __putc('c');
        __putc('\n');
    }
     n=kernel_memfree(c4);
    if(n!=0){
        __putc('G');
        __putc('R');
        __putc('E');
        __putc('S');
        __putc('K');
        __putc('A');
        __putc(' ');
        __putc('d');
        __putc('e');
        __putc('a');
        __putc('l');
        __putc('l');
        __putc('o');
        __putc('c');
        __putc('\n');
    }
     n=kernel_memfree(c5);
    if(n!=0){
        __putc('G');
        __putc('R');
        __putc('E');
        __putc('S');
        __putc('K');
        __putc('A');
        __putc(' ');
        __putc('d');
        __putc('e');
        __putc('a');
        __putc('l');
        __putc('l');
        __putc('o');
        __putc('c');
        __putc('\n');
    }
    char* c=nullptr;
    static long* t;
    n=kernel_memfree((void*)c);
    if(n!=0){
        __putc('G');
        __putc('R');
        __putc('E');
        __putc('S');
        __putc('K');
        __putc('A');
        __putc(' ');
        __putc('d');
        __putc('e');
        __putc('a');
        __putc('l');
        __putc('l');
        __putc('o');
        __putc('c');
        __putc('\n');
    }
    n=kernel_memfree(t);
    if(n!=0){
        __putc('G');
        __putc('R');
        __putc('E');
        __putc('S');
        __putc('K');
        __putc('A');
        __putc(' ');
        __putc('d');
        __putc('e');
        __putc('a');
        __putc('l');
        __putc('l');
        __putc('o');
        __putc('c');
        __putc('\n');
    }
    return 0;
}*/


#include "../lib/console.h"
typedef struct _sem* sem_t;
typedef unsigned long time_t;
extern int semopen(sem_t*,unsigned);
extern int semclose(sem_t);
extern int semwait(sem_t);
extern int semsignal(sem_t);
extern int timesleep(time_t);
int sem_open(sem_t* handle,unsigned init){
    return semopen(handle,init);
}
int sem_close(sem_t handle){
    return semclose(handle);
}
int sem_wait(sem_t handle){
    return semwait(handle);
}
int sem_signal(sem_t handle){
    return semsignal(handle);
}
int time_sleep(time_t time){
    return timesleep(time);
}

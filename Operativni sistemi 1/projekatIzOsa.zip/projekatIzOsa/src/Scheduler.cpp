#include "../h/Scheduler.hpp"


Scheduler* Scheduler::s=nullptr;
_thread* Scheduler::idle=nullptr;
Scheduler::Ready* Scheduler::front=nullptr;
Scheduler::Ready* Scheduler::rear=nullptr;

void idleFunction(void* arg){//arg mi ne treba,ali treba radi poziva fje,pa saljem nullptr
    while(!Scheduler::isEmpty()){
        promjeniRezim2();
    }
    promjeniRezim2();

}

Scheduler::Scheduler() {
    idle=nullptr;
}
void Scheduler::put(_thread *current) {
    if(current==idle  && idle!=nullptr && front!=nullptr){
        //printString("\nusao ovde1\n");
        kernel_memfree(idle);
        idle=nullptr;
        current=nullptr;
    }
    if(current==nullptr )return;

    if(front==nullptr) {
       // printString("\nusao ovde2\n");
        int i=sizeof(Ready)/MEM_BLOCK_SIZE;
        if(sizeof(Ready)%MEM_BLOCK_SIZE!=0)i++;
        front= (Ready*)kernel_memalloc(i);
        rear=front;
        if(!front)return;
        front->t=current;
        front->next=nullptr;

    }
   else {
        //printString("\nusao ovde3\n");
        int i=sizeof(Ready)/MEM_BLOCK_SIZE;
        if(sizeof(Ready)%MEM_BLOCK_SIZE!=0)i++;
        rear->next= (Ready*)kernel_memalloc(i);
        rear=rear->next;
        if(!rear)return;
        rear->t=current;
        rear->next=nullptr;
   }



}

_thread *Scheduler::get() {
   /* printString("spremne:\n");
    for(Ready* node=front;node!=nullptr;node=node->next){
        printInteger((uint64)node->t);
        printString(" ");
    }
    printString("\n");*/
    if(front==nullptr){
       if(!isEmpty()){
            void *idlestck=kernel_memalloc(DEFAULT_STACK_SIZE/MEM_BLOCK_SIZE);
            if (idlestck!=0) {
                idle = _thread::CreateThreadN(idleFunction, idlestck, nullptr);
                return idle;
            }
        }
       return nullptr;
    }
    _thread* tmp=front->t;

    //front->t=0;
    Ready* temp=front;
    front=front->next;

    kernel_memfree(temp);
    if(front==nullptr ) {
        rear = nullptr;

    }





    return tmp;

}

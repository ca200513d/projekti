a#include "../lib/hw.h"
#include "../lib/console.h"
#include "../h/_thread.hpp"
#include "../h/_sem.hpp"
extern  void* kernel_memalloc(size_t);
typedef void(*FunPointer)(void*);
_sem* itemAvailable;
typedef _thread* thread_t;

struct buffer{
    int head;
    int tail;
    int size;
    int current;
    char* buf;
};
buffer *b=nullptr;
extern "C" int thread_create2(thread_t* handle,FunPointer start_routine,void* arg,void*stack_space){
    *handle=_thread::CreateThreadN(start_routine,stack_space,arg,DEFAULT_TIME_SLICE);
    if(*handle==0){

        return -1;
    }

    return 0;
}
extern "C" int thread_create1(thread_t* handle,FunPointer start_routine,void* arg,void* stack_space){


    *handle=_thread::CreateThread(start_routine,stack_space,arg,DEFAULT_TIME_SLICE);

    if(*handle==0){

        return -1;
    }

    return 0;
}
extern "C" int thread_exit1(){
    _thread::exit();
    return -1;//ako je greska da se vrati,inace se nece vratiti
}
extern "C" void thread_dispatch1(){
    _thread::dispatch();

}
extern "C" void blockRunning2(thread_t handle){
    if(handle!=nullptr)handle->blockRunning();
}

extern "C" char getcSIS(){
    itemAvailable->semWait();//ako je bafer prazan ili jos ne postoji,nit se blokira
    char c=b->buf[b->tail];
    b->tail=(b->tail+1)%b->size;
    b->current--;
    return c;

}
extern "C" void myConsoleHandler(){

    if(plic_claim()!=10)return;



    if(!b){ //AKO nije inicijalizovan semafor i bafer
        int i=sizeof(buffer)/MEM_BLOCK_SIZE;
        if(sizeof(buffer)%MEM_BLOCK_SIZE!=0)i++;
        b=(buffer*)kernel_memalloc(i);
        if(!b)return;
        i=sizeof(int)/MEM_BLOCK_SIZE;
        if(sizeof(int)%MEM_BLOCK_SIZE!=0)i++;
        b->buf=(char*) kernel_memalloc(i*1024);
        if(!b->buf){
            kernel_memfree(b);
            return ;
        }
        b->head=b->tail=0;
        b->size=1024;
        b->current=0;
        i=_sem::semOpen(&itemAvailable,0);
        if(i<0){
            kernel_memfree(b->buf);
            kernel_memfree(b);
            return;
        }


    }

    while((*(char*)CONSOLE_STATUS & CONSOLE_RX_STATUS_BIT)&& b->current<b->size){
        char c=*((char*)CONSOLE_RX_DATA);
        //if(c=='\r')c='\n';
        b->buf[b->head]=c;
        b->head=(b->head+1)%b->size;
        b->current++;
        itemAvailable->semSignal();//ako su se niti zaglavile jer je bafer bio prazan

    }
    plic_complete(10);

}
#include "../lib/console.h"
#include "../lib/hw.h"
typedef struct _thread* thread_t;
extern int threadcreate(thread_t* handle,void(*start_routine)(void*),void* arg,void* stack_space);
extern int threadcreate2(thread_t* handle,void(*start_routine)(void*),void* arg,void* stack_space);
extern int threadexit();
extern void threaddispatch();
extern void* kernelmemalloc(size_t);
extern void kernelmemfree(void*);
extern void blockRunningABI(thread_t handle);
extern char getCABI();
extern void putcABI(char);

void* mem_alloc(size_t s){
    size_t i=s/MEM_BLOCK_SIZE;
    if(s%MEM_BLOCK_SIZE!=0)i+=1;

    return kernelmemalloc(i);
}
void mem_free(void* v){
    kernelmemfree(v);
}
int thread_create(thread_t* handle,void(*start_routine)(void*),void* arg) {
    void *stack = mem_alloc(DEFAULT_STACK_SIZE);
    if (!stack)return -1;

    return threadcreate(handle, start_routine, arg, stack);
}
int thread_create3(thread_t* handle,void(*start_routine)(void*),void* arg){
    void* stack=mem_alloc(DEFAULT_STACK_SIZE);
    if(!stack)return -1;
    return threadcreate2(handle,start_routine,arg,stack);
}
int thread_exit(){
    return threadexit();
}
void thread_dispatch(){
    threaddispatch();
}
void blockRunningCAPI(thread_t handle){
    blockRunningABI(handle);
}
char getc(){
    return getCABI();
}
void putc(char c){
    putcABI(c);
}

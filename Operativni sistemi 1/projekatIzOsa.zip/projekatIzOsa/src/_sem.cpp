//
// Created by os on 6/19/22.
//

#include "../h/_sem.hpp"
int _sem::numOfSem=0;
Sleeping* _sem::first=nullptr;
int _sem::semOpen(sem_t *handle, unsigned int init) {
    int i=sizeof(_sem)/MEM_BLOCK_SIZE;
    if(sizeof(_sem)%MEM_BLOCK_SIZE>0)i++;
    _sem* pom=(_sem*)kernel_memalloc(i);

    if(!pom)return -1;
    pom->val=init;

    pom->head=pom->current=nullptr;
    *handle=pom;
    return 0;

}

int _sem::semClose(sem_t handle) {

   if(handle==nullptr)return -1;

    Wait* tmp=handle->head;
    while(tmp){
        tmp->ret=-1;//znaci iz wait treba da vrati ovu vrijednost
        tmp=tmp->next;
        handle->semSignal();


    }
    return 0;
}

int _sem::semWait() {
   if(_thread::running!=nullptr){
       val--;
       if(val>=0)return 0;//onda ne treba da se zaglavi
       if(head==nullptr){
           int i=sizeof(Wait)/MEM_BLOCK_SIZE;
           if(sizeof(Wait)%MEM_BLOCK_SIZE>0)i++;
           head=(Wait*)kernel_memalloc(i);
           current=head;
           if(!head)return -1;
           head->t=_thread::running;
           head->next=nullptr;
           head->ret=0;
       }
       else if(head!=nullptr){
           int i=sizeof(Wait)/MEM_BLOCK_SIZE;
           if(sizeof(Wait)%MEM_BLOCK_SIZE>0)i++;
           current->next= (Wait*)kernel_memalloc(i);
           current=current->next;
           if(!current)return -1;
           current->t=_thread::running;
           current->next=nullptr;
           current->ret=0;
       }
       numOfSem++;
       Wait* blocked=current;//treba ispred,posto se posle izbrise ovaj cvor
      _thread::dispatchBlock();//isto kada se stavlja u red Blocked,da se promjeni tekuca nit
      return blocked->ret;
   }
   return -2;

}

int _sem::semSignal() {
    val++;
    if(val>0)return 0;
    if(head==nullptr)return 0;
    else {
        _thread* tmp=head->t;
        Scheduler::put(tmp);//vrati da je nit spremna
        Wait* tmpp=head;
        head=head->next;
        if(head==nullptr){
            current=nullptr;

        }
        kernel_memfree(tmpp);
        numOfSem--;
        return 0;
    }
}
int _sem::timeSleep(unsigned long time){
    if(time==0)return 0;//ne spava onda,a manje od 0 ne moze biti jer je unsigned
    Sleeping*newnode;
    int i=sizeof(Sleeping)/MEM_BLOCK_SIZE;
    if(sizeof(Sleeping)%MEM_BLOCK_SIZE!=0)i++;
    newnode=(Sleeping*)kernel_memalloc(i);
    if(!newnode)return -1;
    newnode->t=_thread::running;
    newnode->next=nullptr;
    if(first==nullptr){
        newnode->timeLeft=time;
        first=newnode;
    }
    else{
        unsigned long timeList=0;//ovo je vrijeme koje sabiram kroz listu
        Sleeping* node=first,*prev=nullptr;
        bool flag=false;
        while(node){
               unsigned long oldTime=timeList;
               timeList+=node->timeLeft;
               if(time<timeList){
                   newnode->timeLeft=time-oldTime;
                   if(prev){
                       newnode->next=node;
                       prev->next=newnode;
                       flag=true;
                       break;
                   }
                   else{
                       newnode->next=first;
                       first=newnode;
                       flag=true;
                       break;

                   }
               }
               prev=node;
               node=node->next;
        }
        if(!flag){
               prev->next=newnode;
               newnode->timeLeft=time-timeList;
        }



    }
    _thread::dispatchBlock();
    return 0;
}

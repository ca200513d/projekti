#include "../h/_sem.hpp"

extern "C" void promjeniRezim();
extern "C" void promjeniRezim2();
extern "C" void printInteger(uint64);
extern "C" void thread_exit();

_thread* _thread::running=nullptr;
_thread::Context* _thread::currentContext=nullptr;
_thread::Context* _thread::vrati=nullptr;
_thread::Context* _thread::vratiTimer=nullptr;
time_t _thread::timeLeft=DEFAULT_TIME_SLICE;
bool _thread::flagTimer=false;
bool _thread::SemSleep(){
    promjeniRezim();
    if(_sem::first!=nullptr ||  _sem::numOfSem>0 )return true;
    return false;
}
void _thread::_threadInit(_thread* t,FunPointer body, size_t timeS,uint64 sp,uint64 ssp,void* arg,void* stack,void* stack2,int flag) {

    if(!vrati){
        int i=sizeof(Context)/MEM_BLOCK_SIZE;
        if(sizeof(Context)% MEM_BLOCK_SIZE!=0)i++;
        vrati=(Context*)kernel_memalloc(i);
        if(!vrati)return;//nece se valjda nikada desiti
    }
    if(!vratiTimer){
        int i=sizeof(Context)/MEM_BLOCK_SIZE;
        if(sizeof(Context)% MEM_BLOCK_SIZE!=0)i++;
        vratiTimer=(Context*)kernel_memalloc(i);
        if(!vratiTimer)return;//nece se valjda nikada desiti
    }

    t->stack=stack;
    t->stack2=stack2;
    t->function=body;
    t->timeSlice=timeS;
    int i=sizeof(Context)/MEM_BLOCK_SIZE;
    if(sizeof(Context)%MEM_BLOCK_SIZE!=0)i++;
    t->context= (Context*)kernel_memalloc(i);
    if(t->context) {
        t->context->ra = (uint64) wrapper;
        t->context->sp = sp;
        t->context->ssp = ssp;
        t->context->sepc=(uint64) pomocna;
        t->context->sstatus=256;
        t->head = t->curr = nullptr;
        t->finished = false;
        t->arg = arg;
        if (flag == 1) {//ako je flag 1,znaci da je u Thread pozvan konstr.sa parametrima,pa odmah stavljamo nit
            //u Scheduler kao da je spremna,inace je samo kreiran akt.obj.,koji se pokrece preko run

            if (body != nullptr and stack != nullptr and !t->finished)Scheduler::put(t);
        }
    }
}
void _thread::dispatch(){
    //printString("dispatch\n");
    Context* oldContext=vrati;
    if(running){
        oldContext=running->context;
        asm volatile("csrr %0,sepc ": "=r"(running->context->sepc));
        //cuva vrijednost sepc->on ukazuje ispod ecall u asembler.S,da bi se moglo posle vratiti
        Scheduler::put(running);
    }
    Context* newContext;
    running=Scheduler::get();
    timeLeft=0;
    if(running==nullptr){
        newContext=vrati;
        currentContext=nullptr;
    }
    else {
        currentContext = running->context;
        newContext = running->context;
    }
  /*  printString("Nova nit:\n");
    printInteger((uint64)running);
    printString("\n");
    printString("ra: ");
    printInteger((uint64)newContext->ra);
    printString("\n");
    printString("sepc: ");
    printInteger((uint64)newContext->sepc);
    printString("\n");

    printInteger((uint64)contextSwitch);*/
    contextSwitch(oldContext,newContext);



}
void _thread::exit(){
    if(running->finished) {
        //printString("exit\n");
        Context *oldContext = running->context;
        Context* newContext;
        running->unblockRunning();
        kernel_memfree(running->stack);
        kernel_memfree(running->stack2);
        running = Scheduler::get();
        if(running==nullptr){
            newContext=vrati;
            currentContext=nullptr;

        }
        else{
            currentContext = running->context;
            newContext = running->context;
        }
      /*  printString("Nova nit:\n");
        printInteger((uint64)running);
        printString("\n");
        printString("ra: ");
        printInteger((uint64)newContext->ra);
        printString("\n");
        printString("sepc: ");
        printInteger((uint64)newContext->sepc);
        printString("\n");*/
        contextSwitch(oldContext, newContext);

    }

}

void _thread::wrapper(){
    vratiUKorisnicki();
}
void _thread::pomocna(){

    running->function(running->arg);
    running->finished=true;
    //OVDE JE U KORISNICKOM REZIMU!
    thread_exit();//vraca se u sistemski

}
void _thread::blockRunning(){
   if(running!=nullptr && !finished){
       if(head==nullptr){
           int i=sizeof(Blocked)/MEM_BLOCK_SIZE;
           if(sizeof(Blocked)%MEM_BLOCK_SIZE!=0)i++;
           head=curr=(Blocked*)kernel_memalloc(i);
           if(!head)return;
           head->t=running;
           head->next=nullptr;
       }
       else if(head!=nullptr){
           int i=sizeof(Blocked)/MEM_BLOCK_SIZE;
           if(sizeof(Blocked)%MEM_BLOCK_SIZE!=0)i++;
           curr=curr->next= (Blocked*)kernel_memalloc(i);
           if(!curr)return;
           curr->t=running;
           curr->next=nullptr;
       }
       _thread::dispatchBlock();
   }
}
void _thread::unblockRunning(){
    Blocked* tmp;
    while(head){
        tmp=head;
        head=head->next;
        Scheduler::put(tmp->t);
        kernel_memfree(tmp);

    }
    curr=head=nullptr;
    //odblokiraju se sve koje su blokirane radi tekuce niti

}






_thread* _thread::CreateThread(FunPointer body,void* stck,void* arg,size_t timeS){
    if(stck==0)return 0;
    uint64 sp=(uint64)stck+DEFAULT_STACK_SIZE;
    void* stacks=kernel_memalloc(DEFAULT_STACK_SIZE/MEM_BLOCK_SIZE);
    if(stacks==0){
        return 0;
    }
    uint64 ssp=(uint64)stacks+DEFAULT_STACK_SIZE;

    int i=sizeof(_thread)/MEM_BLOCK_SIZE;
    if(sizeof(_thread)%MEM_BLOCK_SIZE!=0)i++;
    _thread* thread=(_thread*)kernel_memalloc(i);
    if(thread==0)return 0;
    _threadInit(thread,body, timeS,sp,ssp,arg,stck,stacks,1);//mozda ne moze ovako

    return thread;

}
_thread* _thread::CreateThreadN(FunPointer body,void* stck,void* arg,size_t timeS){
    if(stck==0)return 0;
    uint64 sp=(uint64)stck+DEFAULT_STACK_SIZE;
    void* stacks=kernel_memalloc(DEFAULT_STACK_SIZE/MEM_BLOCK_SIZE);
    if(stacks==0){
        return 0;
    }
    uint64 ssp=(uint64)stacks+DEFAULT_STACK_SIZE;
    int i=sizeof(_thread)/MEM_BLOCK_SIZE;
    if(sizeof(_thread)%MEM_BLOCK_SIZE!=0)i++;
    _thread* thread=(_thread*)kernel_memalloc(i);
    if(thread==0)return 0;
    _threadInit(thread,body, timeS,sp,ssp,arg,stck,stacks,0);//mozda ne moze ovako


    return thread;

}

void _thread::dispatchBlock() {
    //printString("dispatchBlock\n");
    asm volatile("csrr %0,sepc ": "=r"(running->context->sepc));

    Context* oldContext=running->context;
    Context* newContext;
    running=Scheduler::get();
    timeLeft=0;
    if(running==nullptr){
        newContext=vrati;
        currentContext=nullptr;

    }
   else{
        currentContext=running->context;
        newContext=running->context;

   }

   /* printString("Nova nit:\n");
    printInteger((uint64)running);
    printString("\n");
    printString("ra: ");
    printInteger((uint64)newContext->ra);
    printString("\n");
    printString("sepc: ");
    printInteger((uint64)newContext->sepc);
    printString("\n");*/
    contextSwitch(oldContext,newContext);
    //flagTimer=false;


}
void _thread::Timer() {
    //azurirati listu uspavanih
    /* printString("zaglavljene:\n");
     for(Sleeping* node=_sem::first;node!=nullptr;node=node->next){
         printInteger((uint64)node->t);
         printString(" ");
         printInteger((uint64)node->timeLeft);
         printString(" ");
     }
     printString("\n");*/
    if (_sem::first)_sem::first->timeLeft--;
    while (_sem::first && _sem::first->timeLeft == 0) {
        Scheduler::put(_sem::first->t);
        Sleeping *tmp = _sem::first;
        _sem::first = _sem::first->next;
        kernel_memfree(tmp);
    }
    //azurirati preostalo vrijeme izvrsavanja
    if (running && timeLeft == running->timeSlice)dispatch();
    else if (!running && timeLeft == DEFAULT_TIME_SLICE)dispatch();
    //else
    timeLeft++;
    flagTimer = true;

}
void _thread::setFinished(){
    finished=true;
    while(this!=Scheduler::get()){
        Scheduler::put(this);
    }
}


#include "../lib/hw.h"
typedef struct _thread* thread_t;
typedef unsigned long time_t;
typedef struct _sem* sem_t;
extern "C" int thread_create(thread_t* handle,void(*start_routine)(void*),void* arg);
extern "C" int thread_create3(thread_t* handle,void(*start_routine)(void*),void* arg);
extern "C" int thread_exit();
extern "C" void thread_dispatch();
extern "C" void* mem_alloc(size_t);
extern "C"  void mem_free(void*);
extern "C" void blockRunningCAPI(thread_t handle);
extern "C" int sem_open(sem_t* handle,unsigned init);
extern "C" int sem_close(sem_t handle);
extern "C" int sem_wait(sem_t handle);
extern "C" int sem_signal(sem_t handle);
extern "C" int time_sleep(time_t s);
extern "C" char getc();
extern "C" void putc(char);
//const char EOF=-1;
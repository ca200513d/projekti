#ifndef _SCHEDULER_HPP_
#define _SCHEDULER_HPP_
#include "_thread.hpp"
#include "print.hpp"
class Scheduler{
public:
    static bool isEmpty() {
        if(_thread::SemSleep())return false;//ako ima blokiranih niti,ceka se
        if(!front && !rear)return true;
        return false;
    }
    static void put(_thread* current);
    static _thread* get();
    struct Ready{
        Ready* next=nullptr;
        _thread* t;
        //Ready(_thread* tt):next(nullptr),t(tt){}
    };
    static _thread* idle;


private:
    static Scheduler* s;
    Scheduler();
    static Ready* front;
    static Ready* rear;

};
#endif



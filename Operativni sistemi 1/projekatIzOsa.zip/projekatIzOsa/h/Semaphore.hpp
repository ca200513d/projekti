

#ifndef PROJECTBASE_SEMAPHORE_HPP
#define PROJECTBASE_SEMAPHORE_HPP
#include "_sem.hpp"
#include "../h/syscall_c.h"

class Semaphore {

public:
    Semaphore(unsigned init=1){
        sem=init;
        int i=sem_open(&myHandle,init);
        if(i<0)myHandle=nullptr;//ako se neispravno inicijalizuje
    }
    virtual ~Semaphore(){
        if(myHandle!=nullptr){
            sem_close(myHandle);
        }
    }

    int wait(){ sem--;return sem_wait(myHandle);}
    int signal(){sem++;return sem_signal(myHandle);}
    int sem;
private:
    sem_t myHandle;
};


#endif //PROJECTBASE_SEMAPHORE_HPP

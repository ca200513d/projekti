#ifndef _Thread_HPP_
#define _Thread_HPP_
#include "Scheduler.hpp"
#include "../h/syscall_c.h"
typedef _thread* thread_t;
typedef void(*FunPointer)(void*);

class Thread{
public:


    Thread(void(*body)(void*),void* arg);


    virtual ~Thread();

    void start();

    static void dispatch();
    static int sleep(time_t time);
    void static pomocnaFja(void* pointer);
protected:
    Thread();

    void static blockRunning(thread_t handle);
    virtual void run(){}
    int flagType;
private:
    thread_t myHandle;

};
#endif

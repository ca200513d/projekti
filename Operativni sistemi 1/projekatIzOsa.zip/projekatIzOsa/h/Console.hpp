//
// Created by os on 6/25/22.
//

#ifndef PROJECTBASE1_CONSOLE_HPP
#define PROJECTBASE1_CONSOLE_HPP
#include "../lib/console.h"
#include "../h/syscall_c.h"
extern "C" char getCABI();
extern "C" void putcABI(char);
class Console {
public:
    static char getc(){
        return getCABI();
    }
    static void putc(char c){
        putcABI(c);
    }
    Console(Console& c)=delete;
    void operator=(Console& c)=delete;
private :
    Console(){}
};


#endif //PROJECTBASE1_CONSOLE_HPP

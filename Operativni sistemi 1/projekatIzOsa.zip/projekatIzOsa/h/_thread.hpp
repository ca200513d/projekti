#ifndef __thread_HPP_
#define __thread_HPP_
#include "../lib/hw.h"
#include "../lib/console.h"
extern "C" void* kernel_memalloc(size_t);
extern "C" void kernel_memfree(void*);
extern void interruptvec1();
typedef unsigned long time_t;
typedef void(*FunPointer)(void*);
class _thread{
private:
    int flag;
    FunPointer function;
    static void _threadInit(_thread* t,FunPointer body,size_t timeS,uint64 sp,uint64 ssp,void* arg,void*stack,void* stack2,int flag);
    static void wrapper();
    struct Context{
        uint64 ra;
        uint64 sp;
        uint64 ssp;
        uint64 sepc;
        uint64 oldSp;
        uint64 sstatus;
        uint razlogSkoka;
    };
    void* arg;
    size_t timeSlice;
    Context* context;
    void *stack;
    void* stack2;
    bool finished;
public:
    void setFinished();//za periodicnu nit,da se zavrsi fja
    static void vratiUKorisnicki();//kada prvi put pokrecemo nit
    static void pomocna();//da se iz wrappera skoci na asembli za prelazak u sis rez,pa onda iz tog asemblija ovde
    static Context* currentContext;
    static Context* vrati;//kada se zavrse sve niti se vrati u main
    static Context* vratiTimer;
    struct Blocked{
        Blocked* next;
        _thread* t;

        Blocked(_thread* tt):next(nullptr),t(tt){}
    };
    Blocked* head;
    Blocked* curr;
    static _thread* running;

    static _thread* CreateThread(FunPointer body,void* stck,void* arg,size_t timeS=DEFAULT_TIME_SLICE);
    static _thread* CreateThreadN(FunPointer body,void* stck,void* arg,size_t timeS=DEFAULT_TIME_SLICE);
    static void dispatch();
    static void dispatchBlock();
    static void exit();
    static void contextSwitch(Context* oldContext,Context* newContext);
    bool isFinished()const{
        return finished;
    }
    void blockRunning();
    void unblockRunning();
    static time_t timeLeft;//kvantum vremena za tekucu nit
    static void Timer();
    static bool flagTimer;//da li je dispatch radi tajmera,pa ako jeste i Scheduler je prazan,da se vrati idle
    static bool SemSleep();//da li ima blokiranih niti
};
#endif
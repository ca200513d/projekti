//
// Created by os on 5/17/22.
//

#ifndef PROJECTBASE_SYSCALL_CPP_H
#define PROJECTBASE_SYSCALL_CPP_H
#include "../h/Console.hpp"
#include "../h/PeriodicThread.hpp"
#include "../h/Semaphore.hpp"
#endif //PROJECTBASE_SYSCALL_CPP_H


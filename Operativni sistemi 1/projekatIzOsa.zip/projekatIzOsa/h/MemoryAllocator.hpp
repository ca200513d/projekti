#include "../lib/hw.h"
extern "C" void* mem_alloc(size_t);
extern "C" void mem_free(void*);
void* operator new(uint64 n){return mem_alloc(n);}
void operator delete(void* p){mem_free(p);}



//
// Created by os on 6/20/22.
//

#ifndef PROJECTBASE1_BUFFER_HPP
#define PROJECTBASE1_BUFFER_HPP
#include "Semaphore.hpp"
const int N=20;
class Buffer {
public:
    Buffer();
    void put(char);
    char get(int consumerID);

private:
    char buf[N];
    int head,tail;
    Semaphore mutex,spaceAvailable,itemAvailable,gate1,gate2;
};


#endif //PROJECTBASE1_BUFFER_HPP

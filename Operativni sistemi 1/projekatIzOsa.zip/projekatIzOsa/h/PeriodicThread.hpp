//
// Created by os on 6/24/22.
//

#ifndef PROJECTBASE1_PERIODICTHREAD_HPP
#define PROJECTBASE1_PERIODICTHREAD_HPP
#include "Thread.hpp"
class PeriodicThread : public Thread{
public:
    PeriodicThread(time_t p):Thread(Pomocna,this){
            period=p;
            flagType=1;
    }
    static void  Pomocna(void* pointer){
        PeriodicThread*p=(PeriodicThread*)pointer;
        while(1){
            sleep(p->period);
            p->periodicActivation();

        }
    }
protected:
    virtual void periodicActivation(){

        }

private:
    time_t period;


};


#endif //PROJECTBASE1_PERIODICTHREAD_HPP

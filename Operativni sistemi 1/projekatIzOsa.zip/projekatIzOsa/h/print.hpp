//
// Created by os on 6/18/22.
//

#ifndef PROJECTBASE_PRINT_HPP
#define PROJECTBASE_PRINT_HPP
#include "../lib/hw.h"
void printString(const char *string);
char* getString();
extern "C" void promjeniRezim();
extern "C" void promjeniRezim2();
extern "C" void printInteger(uint64 integer);
extern "C" char getc();
extern "C" void putc(char c);
void swap(int prvi,int drugi);
#endif //PROJECTBASE_PRINT_HPP

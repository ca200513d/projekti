

#ifndef __sem_HPP_
#define __sem_HPP_
#include "Scheduler.hpp"
class _sem;
typedef _sem* sem_t;
struct Sleeping{
    _thread * t;
    Sleeping* next;
    unsigned long timeLeft;
};
class _sem {
public:

    static int semOpen(sem_t* handle,unsigned init);
    static int semClose(sem_t handle);

    int semWait();
    int semSignal();
    static int timeSleep(unsigned long time);
private :
    struct Wait{
        _thread* t;
        Wait* next;
        int ret;//sta treba da vrati nit,koja se oslobadja sa semafora
    };//lista niti koje cekaju
    int val;//vrijednost semafora,mora int,jer ako ide unsigned,ne moze biti manje od 0
    Wait* head;
    Wait* current;
public:

    static Sleeping* first;
    static int numOfSem;
    int getValue(){
        return val;
    }

};


#endif

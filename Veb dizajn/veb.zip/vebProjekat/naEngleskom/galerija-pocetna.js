$(document).ready(
    function(){ 
       
        let t=null;
        let o=0;

        let t1=null;
        let o1=0;
        pojacaj();
        umetnici();

        function pojacaj(){ 
            if(t!=null){ 
                clearTimeout(t);
                t=null;
            }
            if(o<1.0){ 
                o+=0.2;
                $('.slika').css({"opacity":o});
                t=setTimeout(pojacaj,300);
            }
            else{ 
                o=0;
                t=setTimeout(log,200);
            }

       }
       function log(){ 
        if(t!=null){ 
            clearTimeout(t);
            t=null;
        }
        if(o<1.0){ 
            o+=0.5;
            $('#l').css({"opacity":o});
            t=setTimeout(log,200);
        }
        else{ 
            o=0;
            t=setTimeout(reg,200);
        }
       }
       function reg(){ 
        if(t!=null){ 
            clearTimeout(t);
            t=null;
        }
        if(o<1.0){ 
            o+=0.5;
            $('#r').css({"opacity":o});
            t=setTimeout(reg,200);
        }
       }
       function umetnici(){ 
        if(t1!=null){ 
            clearTimeout(t1);
            t1=null;
        }
        if(o1<1.0){ 
            o1+=0.2;
            $('.card').css({"opacity":o1});
            t1=setTimeout(umetnici,300);
        }

   }
       $(".checkbox-dropdown").click(function () {
        $(this).toggleClass("is-active");
    });
    
    $(".checkbox-dropdown ul").click(function(e) {
        e.stopPropagation();
    });
    $("#dugme1").click(function(){ 
        $("#dugme1").css({"background-color":"rgb(65, 63, 63)"});
        $("#dugme2").css({"background-color":"white"});
        $("#dugme3").css({"background-color":"white"});

        $("#slika1").remove();
        $(".column1").append("<img src='images/galerija1.jpg' id='slika1'></img>")
    });
    $("#dugme2").click(function(){ 
        $("#dugme2").css({"background-color":"rgb(65, 63, 63)"});
        $("#dugme1").css({"background-color":"white"});
        $("#dugme3").css({"background-color":"white"});

        $("#slika1").remove();
        $(".column1").append("<img src='images/galerija3.jpeg' id='slika1'></img>")
    });
    $("#dugme3").click(function(){ 
        $("#dugme3").css({"background-color":"rgb(65, 63, 63)"});
        $("#dugme2").css({"background-color":"white"});
        $("#dugme1").css({"background-color":"white"});

        $("#slika1").remove();
        $(".column1").append("<img src='images/galerija4.jpeg' id='slika1'></img>")
    });
    $(".dugme").click(function(){ 
        let kod=""
    });
    var breadcrumbs = [];


    function addBreadcrumb(pageName, pageURL) {
      var breadcrumb = {
        name: pageName,
        url: pageURL
      };
      breadcrumbs.push(breadcrumb);
    }
    
    
    function displayBreadcrumbs() {
      var breadcrumbContainer = document.getElementById('breadcrumb-container');
      if(breadcrumbContainer==null)return;
      breadcrumbContainer.innerHTML = '';
    
      for (var i = 0; i < breadcrumbs.length; i++) {
        var breadcrumb = breadcrumbs[i];
        var breadcrumbLink = document.createElement('a');
        breadcrumbLink.href = breadcrumb.url;
        breadcrumbLink.textContent = breadcrumb.name;
    
        if (i === breadcrumbs.length - 1) {
          breadcrumbLink.classList.add('active');
        }
    
        breadcrumbContainer.appendChild(breadcrumbLink);
    
        if (i !== breadcrumbs.length - 1) {
          var separator = document.createElement('span');
          separator.textContent = '->';
          breadcrumbContainer.appendChild(separator);
        }
      }
    }
    var currentURL = window.location.href.split('/');
    
        addBreadcrumb('Home', window.location.href.split('naEngleskom/')[0] + 'naEngleskom/index.html');
    
    if(currentURL[currentURL.length-1]=='zena-sa-suncobranom.html'){
        addBreadcrumb('Art', window.location.href.split(('naEngleskom/'))[0] + '/naEngleskom/umetnine-slike.html');
        addBreadcrumb('Woman with an umbrella', window.location.href);
    }else if(currentURL[currentURL.length-1]=='pred-prolece.html'){
        addBreadcrumb('Art', window.location.href.split(('naEngleskom/'))[0] + '/naEngleskom/umetnine-slike.html');
        addBreadcrumb('Before spring', window.location.href);
    }else if(currentURL[currentURL.length-1]=='seobe-srba.html'){
        addBreadcrumb('Art', window.location.href.split(('naEngleskom/'))[0] + '/naEngleskom/umetnine-slike.html');
        addBreadcrumb('The Migration of Serbs', window.location.href);
    }else if(currentURL[currentURL.length-1]=='pobednik.html'){
        addBreadcrumb('Sculpture', window.location.href.split(('naEngleskom/'))[0] + '/naEngleskom/umetnine-skulpture.html');
        addBreadcrumb('Winner', window.location.href);
    }else if(currentURL[currentURL.length-1]=='vuk-karadzic.html'){
        addBreadcrumb('Sculpture', window.location.href.split(('naEngleskom/'))[0] + '/naEngleskom/umetnine-skulpture.html');
        addBreadcrumb('Vuk Karadžić', window.location.href);
    }else if(currentURL[currentURL.length-1]=='autoportret.html'){
        addBreadcrumb('Sculpture', window.location.href.split(('naEngleskom/'))[0] + '/naEngleskom/umetnine-skulpture.html');
        addBreadcrumb('Self-portrait', window.location.href);
    }
    
    
    displayBreadcrumbs();
    

   }
    
);



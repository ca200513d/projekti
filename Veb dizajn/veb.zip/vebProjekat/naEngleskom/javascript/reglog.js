$(document).ready(function () {
    var AllUsers = [
        {
            name: 'Anja',
            surname: 'Curic',
            email: 'anjacuric@gmail.com',
            password: 'anja'
        },
        {
            name: 'Lana',
            surname: 'Ivkovic',
            email: 'lanaivkovic@gmail.com',
            password: 'lana'
        }

    ];
    var arts = [
        {
            art: 'Pred prolece',
            offer: 0
        },
        {
            art: 'Zena sa suncobranom',
            offer: 0
        },
        {
            art: 'Vuk Karadzic',
            offer: 0
        },
        {
            art: 'Pobednik',
            offer: 0
        },
        {
            art: 'Autoportret',
            offer: 0
        },
        {
            art: 'Seoba Srba',
            offer: 0
        }
    ]
    if(!localStorage.getItem('all_offers')){
        localStorage.setItem('all_offers',JSON.stringify(arts));

    }
    localStorage.setItem("AllUsers", JSON.stringify(AllUsers));

    //pomocne
    var new_user = {
        name: "",
        surname: "",
        email: "",
        password: ""
    }
    $logged = localStorage.getItem("loggedin");
    if($logged){
        $("#nologged").prop('hidden',true);
    }
    init();

    function init(){ 
        if(localStorage.getItem("emailRemember")!=null){ 
            $("#email").val(JSON.parse(localStorage.getItem("emailRemember")));
            $("#password").val(JSON.parse(localStorage.getItem("passwordRemember")));
        }
    }
    $("#login").click(function () {
        var flag=false;
        AllUsers.forEach(element => {
            if ($("#email").val() == element.email && $("#password").val() == element.password) {
                localStorage.setItem("loggedin", JSON.stringify(element));
                window.location.href = "index.html";
                flag=true;
            }
        });
       if(!flag){ 
            console.log($("#msg").text());
            $("#msg").text("Neispravni kredencijali"); // eng promjena
       }
       else if($("#remember").val()=="on"){ 
            localStorage.setItem("emailRemember",JSON.stringify($("#email").val()));
            localStorage.setItem("passwordRemember",JSON.stringify($("#password").val()));
       }

    })

    $("#register").click(function () {

        var emailregex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        var passwordregex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()\-_=+{};:,<.>]).{8,}$/;
        if ($("#name").val() != "") {
            new_user.name = $("#name").val();
            var flag =false;
            if ($("#surname").val() != "") {
                new_user.surname = $("#surname").val();
                if ($("#password").val() != "" && passwordregex.test($("#password").val())) {
                    $("#passwordInfo").text("Lozinka je validna.");
                    $("#passwordInfo").addClass("valid-password").removeClass("invalid-password");
                    new_user.password = $("#password").val();
                    flag=true;
                }
                else {
                    $("#passwordInfo").text("Password is not valid. It should contain at least 8 characters, at least one digit, at least one lowercase letter, at least one uppercase letter, and at least one special character.");
                    $("#passwordInfo").addClass("invalid-password").removeClass("valid-password");
                }
                if ($("#email").val() != "" && emailregex.test($("#email").val())) {

                    AllUsers.forEach(element => {
                        console.log(element.email);
                        console.log($("#email").val());
                        console.log(element.email == $("#email").val());
                        if (element.email == $("#email").val()) {
                            console.log("usao");
                            $("#msg").text("A user is already registered with this email!");
                            flag=false;
                        }
                    });
                    new_user.email = $("#email").val();
                    if(flag){
                        
                        $("#msg").css("color", "green");
                        $("#msg").text("You have been successfully registered. Please proceed to the main page!");
                        AllUsers.push(new_user);
                        localStorage.setItem('AllUsers', JSON.stringify(AllUsers));
                        setTimeout(function () {
                            localStorage.setItem("loggedin", JSON.stringify(new_user));
                            window.location.href = "o-nama.html";
    
                        }, 1500);
                    }
                    
                } else {
                    $("#msg").text("Invalid email address. Please fill in a valid email address."); // eng promjena
                }


            } else {
                $("#msg").text("The last name field is not filled in. Please provide your last name."); // eng promjena
            }

        } else {
            $("#msg").text("The first name field is not filled in. Please provide your first name."); // eng promjena
        }

    })



})
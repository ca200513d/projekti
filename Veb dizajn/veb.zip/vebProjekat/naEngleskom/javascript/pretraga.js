$(document).ready(function () {
    let t=null;
    let o=0;
    var art = [
        {
            name: 'Woman with an umbrella',
            artist: 'Nadežda Petrović',
            jpg: 'images/nadezda-kaver.jpg',
            html: 'zena-sa-suncobranom.html',
            id: 'slika1'
        },
        {
            name: 'Before spring',
            artist: 'Sava Šumanović',
            jpg: 'images/Sava_SumanoviC_-_Pred_prolecE_1934.jpg',
            html: 'pred-prolece.html',
            id: 'slika2'
        },
        {
            name: 'The Migration of Serbs',
            artist: 'Paja Jovanović',
            jpg: 'images/Seoba_Srba.jpg',
            html: 'seobe-srba.html',
            id: 'slika3'
        }
    ];

    var sculptures = [
        
        {
            name: 'Winner',
            artist: 'Ivan Meštrović',
            jpg: 'images/mestrovic1.jpg',
            html: 'autoportret.html',
            
        },
        {
            name: 'Vuk Karadžić',
            artist: 'Petar Ubavkić',
            jpg: 'images/vuk_karadzic.jpg',
            html: 'vuk-karadzic.html',
           
        },
        {
            name: 'Self-portrait',
            artist: 'Ivan Meštrović',
            jpg: 'images/mestrovic2.jpg',
            html: 'autoportret.html',
            
        }

    ];

    $("#search_btn_art").click(function () {
        console.log("art");
        var name = $("#search_art").val();
        var selected_art = [];
        if (!name) {
            selected_art = art;
        } else {
            console.log("name");
            art.forEach(element => {
                console.log()
                if (element.name.includes(name) || element.artist.includes(name)) {
                    selected_art.push(element);
                }
            });
        }
        if ($("#artist").is(":checked")) {
            console.log("po artistu");
            selected_art.sort(compareByArtist);
        }
        if ($("#name").is(":checked")) {
            console.log("po name");
            selected_art.sort(compareByName);
        }
        console.log(selected_art);
        //prikazati
        var htmlCode ='';
        var i = 1;
        selected_art.forEach(element => {
            htmlCode =  htmlCode + '<div class="col-4 kol4" id="slika' +i + '"><a href="'+element.html + '">';
            htmlCode =htmlCode + '<img class="img-fluid slika " src="';
            htmlCode += element.jpg + ' "opacity="1"/></a><br/><p class="tekstIspod">' + element.name+ '</p> </div>'
            i++;
        });
        $("#display_art").html(htmlCode);
        pojacaj();

    });

    $("#search_btn_sc").click(function () {
        var name = $("#search_sc").val();
        var selected_art = [];
        if (!name) {
            selected_art = sculptures;
        } else {
            
            sculptures.forEach(element => {
                console.log()
                if (element.name.includes(name) || element.artist.includes(name)) {
                    selected_art.push(element);
                }
            });
        }
        if ($("#artist").is(":checked")) {
            console.log("po artistu");
            selected_art.sort(compareByArtist);
        }
        if ($("#name").is(":checked")) {
            console.log("po name..");
            selected_art.sort(compareByName);
        }
        console.log(selected_art);
        //prikazati
        console.log("alaaa");
        var htmlCode ='';
        var i =1;
        $("#display_sc").empty();
            selected_art.forEach(element => {
            console.log(i);
            htmlCode =$('<div class="col-4 kol4" id="slika' +i + '"></div>');
            h2 = $('<a href="' + element.html + '"></a><br/>')
            im= $('<img class="img-fluid slika" src="'+element.jpg+'" opacity="1"/>');
            h2.append(im);
            po = $('<p  class="tekstIspod">' + element.name +'</p>')
            htmlCode.append(h2).append(po);
            $("#display_sc").append(htmlCode)
            i++;
        });
        
        pojacaj();

    })



    function compareByArtist(a,b){
        if (a.artist < b.artist) {
            return -1;
          }
          if (a.artist > b.artist) {
            return 1;
          }
          return 0;
    }
    function compareByName(a,b){
        if (a.name < b.name) {
            return -1;
          }
          if (a.name > b.name) {
            return 1;
          }
          return 0;
    }
    function pojacaj(){ 
        if(t!=null){ 
            clearTimeout(t);
            t=null;
        }
        if(o<1.0){ 
            o+=0.2;
            $('.slika').css({"opacity":1});
            t=setTimeout(pojacaj,300);
        }

   }
});
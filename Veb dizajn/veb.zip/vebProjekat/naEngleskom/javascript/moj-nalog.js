$(document).ready(
    function () {
        init();

        function init() {
            if (JSON.parse(localStorage.getItem("loggedin")) == null) {
                $(".tijelo").html("<div><h1 align='center' class='noviFont boja2' style='font-weight:bolder;font-size:50px'>Please login!</h1><div align='center'><a class='link1' href='login.html'>Log in</a>&nbsp;&nbsp;<a class='link1' href='registracija.html'>Sign Up</a></div></div>");
            }
            else {
                var kod = "";
                $(".tijelo").html("<div><h1 align='center' class='noviFont boja2' style='font-weight:bolder;font-size:50px'>Log out</h1></div><div style='display: flex; justify-content: center; margin-top: 10px;'><button id='logout' class='btn dugme1'>Log out</button></div>");
                var logedin = JSON.parse(localStorage.getItem('loggedin'));
                var moji_kom = JSON.parse(localStorage.getItem(logedin.email + 'com'));
                var moje_ponude = JSON.parse(localStorage.getItem(logedin.email + 'offer'));
                moje_ponude = prevedi(moje_ponude);
                var tabela = $("#komentari");


                if (moji_kom) {
                    for (var i = 0; i < moji_kom.length; i++) {
                        var red1 = $("<tr></tr>");
                        red1.append("<td>" + moji_kom[i].art + "</td>");
                        red1.append("<td>" + moji_kom[i].offer + "</td>");
                        red1.append("<td><input type='checkbox' name='kom' class='kom' id=" + i + '-' + logedin.name + "></td>");
                        tabela.append(red1);
                    }
                }


                var tabela = $("#ponude");
                if (moje_ponude) {
                    for (var i = 0; i < moje_ponude.length; i++) {
                        var red1 = $("<tr></tr>");
                        red1.append("<td>" + moje_ponude[i].art + "</td>");
                        red1.append("<td>" + moje_ponude[i].offer + "</td>");
                        red1.append("<td><input type='checkbox' name='pon' class='pon' id=" + i + '-' + logedin.name + "></td>");
                        tabela.append(red1);
                    }
                }



            }


        }

        $("#logout").click(function () {
            if (localStorage.getItem("loggedin") != null) {
                localStorage.setItem("loggedin", null);
                window.location.href = "login.html";
            }

        })
        $("#potvrdi_kom").click(function () {
            var logedin = JSON.parse(localStorage.getItem('loggedin'));
            var art = document.title;

            var sve = []
            if (localStorage.getItem(logedin.email + 'com')) {
                sve = JSON.parse(localStorage.getItem(logedin.email + 'com'));

            }

            var ostavio = {
                offer: $("#price").val(),
                art: art
            }

            if ($("#price") == "Comment...") { return; }
            sve.push(ostavio);

            localStorage.setItem(logedin.email + 'com', JSON.stringify(sve));


        });
        $("#potvrdi_ponudu").click(function () {
            $(".canvas").empty();
            var logedin = JSON.parse(localStorage.getItem('loggedin'));
            var art = document.title;
            console.log(art);
            var sve = []
            if (localStorage.getItem(logedin.email + 'offer')) {
                sve = JSON.parse(localStorage.getItem(logedin.email + 'offer'));

            }
            var ostavio = {
                offer: $("#price1").val(),
                art: art
            }
            if ($("#price1") == "") { return; }
            sve.push(ostavio);
            var flag = false;
            localStorage.setItem(logedin.email + 'offer', JSON.stringify(sve));
            licitacije = JSON.parse(localStorage.getItem('all_offers'));
            for (var i = 0; i < licitacije.length; i++) {

                if (licitacije[i].art == art && licitacije[i].offer < parseInt($("#price1").val())) {
                    licitacije[i].price = parseInt($("#price1"));

                    flag = true;
                } else if (licitacije[i].art == art && licitacije[i].offer) {
                    flag = false;
                    break;
                }
            }
            licitacije.push(ostavio);
            localStorage.setItem('all_offers', JSON.stringify(licitacije));

            if (flag == true) {
                console.log('jej');


                $(".canvas").append('<canvas style="width: 100%; " id="konfeteCanvas"></canvas>')

                dodajKonfete();
                animirajKonfete();
            }


        });
        $("#btn-close").click(function () {


        })
        $(".ponude").click(function () {
            
            var selectedValues = $('input[name="pon"]:checked').map(function () {
                return $(this).attr('id');
            }).get();
            novi = [];
            var logedin = JSON.parse(localStorage.getItem('loggedin'));
            var moje_ponude = JSON.parse(localStorage.getItem(logedin.email + 'offer'));

            selectedValues.forEach(id => {

                var num = parseInt(id.split('-')[0]);
                novi.push(num);
            });
            var tabela = $("#ponude");
            tabela.empty();
            var m = [];
            for (var i = 0; i < moje_ponude.length; i++) {
                if (!novi.includes(i)) {
                    var red1 = $("<tr></tr>");
                    red1.append("<td>" + moje_ponude[i].art + "</td>");
                    red1.append("<td>" + moje_ponude[i].offer + "</td>");
                    red1.append("<td><input type='checkbox' name='pon' class='pon' id=" + i + '-' + logedin.name + "></td>");
                    tabela.append(red1);
                    m.push(moje_ponude[i]);
                }
            }
            moje_ponude = m;
            localStorage.setItem(logedin.email + 'offer', JSON.stringify(moje_ponude));

        });


        $(".komentari").click(function () {
            var selectedValues = $('input[name="kom"]:checked').map(function () {
                return $(this).attr('id');
            }).get();
            var novi = [];
            var logedin = JSON.parse(localStorage.getItem('loggedin'));
            var moji_kom = JSON.parse(localStorage.getItem(logedin.email + 'com'));
            

            selectedValues.forEach(id => {
                var num = parseInt(id.split('-')[0]);
                novi.push(num);
            });
            console.log(novi);
            var m = [];
            var tabela = $("#komentari");
            tabela.empty();
            for (var i = 0; i < moji_kom.length; i++) {
                if (!novi.includes(i)) {
                    var red1 = $("<tr></tr>");
                    red1.append("<td>" + moji_kom[i].art + "</td>");
                    red1.append("<td>" + moji_kom[i].offer + "</td>");
                    red1.append("<td><input type='checkbox' name='kom' class='kom' id=" + i + '-' + logedin.name + "></td>");
                    tabela.append(red1);
                    m.push(moji_kom[i]);
                }
            }
            moji_kom = m;
            localStorage.setItem(logedin.email + 'com', JSON.stringify(moji_kom));




        });


        const konfete = [];

        function generisiKonfetu() {
            var canvas = $('#konfeteCanvas')[0];
            const ctx = canvas.getContext('2d');
            const konfeta = {
                x: Math.random() * canvas.width,
                y: canvas.height,
                velX: (Math.random() - 0.5) * 2, // Slučajna brzina po X osi
                velY: -Math.random() * 3, // Negativna brzina po Y osi za kretanje nagore
                boja: getRandomColor(),
                velicina: Math.random() * 10 + 5 // Slučajna veličina konfete
            };

            konfete.push(konfeta);
        }

        function getRandomColor() {
            const letters = '0123456789ABCDEF';
            let color = '#';
            for (let i = 0; i < 6; i++) {
                color += letters[Math.floor(Math.random() * 16)];
            }
            return color;
        }

        function animirajKonfete() {
            var canvas = $('#konfeteCanvas')[0];
            const ctx = canvas.getContext('2d');


            ctx.clearRect(0, 0, canvas.width, canvas.height);

            for (let i = 0; i < konfete.length; i++) {
                let konfeta = konfete[i];
                konfeta.x += konfeta.velX;
                konfeta.y += konfeta.velY;

                ctx.beginPath();
                ctx.arc(konfeta.x, konfeta.y, konfeta.velicina, 0, Math.PI * 2);
                ctx.fillStyle = konfeta.boja;
                ctx.fill();
                ctx.closePath();

                if (konfeta.y + konfeta.velicina < 0) {
                    konfete.splice(i, 1); // Ukloni konfetu iz niza ako izađe izvan canvas-a
                    i--;
                }
            }

            requestAnimationFrame(animirajKonfete);
        }

        function dodajKonfete() {

            setInterval(generisiKonfetu, 100); // Dodaj novu konfetu svakih 100ms
        }
        function prevedi(moji) {
            var engl = ['Winner', 'Vuk Karadžić', 'Self-portrait', 'Woman with an umbrella', 'Before spring', 'The Migration of Serbs'];
            var srp = ['Pobednik', 'Vuk Karadžić', 'Autoportret', 'Žena sa suncobranom', 'Pred prolece', 'Seoba Srba'];
            if(!moji){return moji;}
            for (var i = 0; i < moji.length; i++) {
                var poz = $.inArray(moji[i].art, srp);
                console.log(moji[i].art);
              
                console.log("prevedii");
                console.log(poz);
                if (poz != -1) {
                    moji[i].art = engl[poz];
                }

            }
            return moji;
        }





    }





);
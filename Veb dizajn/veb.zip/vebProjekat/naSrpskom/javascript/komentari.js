$(document).ready(function () {
    $svi_komentari
})
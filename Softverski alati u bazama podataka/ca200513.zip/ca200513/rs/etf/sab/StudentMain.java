/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import rs.etf.sab.operations.*;
import org.junit.Test;
import rs.etf.sab.student.*;
import rs.etf.sab.tests.TestHandler;
import rs.etf.sab.tests.TestRunner;

import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Assert;

public class StudentMain {

    public static void main(String[] args) {

        ArticleOperations articleOperations = new ca200513_ArticleOperations(); // Change this for your implementation (points will be negative if interfaces are not implemented).
        BuyerOperations buyerOperations =new ca200513_BuyerOperations();
        CityOperations cityOperations = new ca200513_CityOperations();
        GeneralOperations generalOperations = new ca200513_GeneralOperations();
        OrderOperations orderOperations = new ca200513_OrderOperations(generalOperations);
        ShopOperations shopOperations = new ca200513_ShopOperations();
        TransactionOperations transactionOperations=new ca200513_TransactionOperations();
        TestHandler.createInstance(
                articleOperations,
                buyerOperations,
                cityOperations,
                generalOperations,
                orderOperations,
                shopOperations,
                transactionOperations
        );

        TestRunner.runTests();
        
        
       
    }
   
 
			
	
}

    

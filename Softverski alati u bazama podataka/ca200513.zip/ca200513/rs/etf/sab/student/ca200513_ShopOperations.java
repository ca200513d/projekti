/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.ShopOperations;

/**
 *
 * @author user2
 */
public class ca200513_ShopOperations implements ShopOperations {
    
     Connection conn = DB.getInstance().getConnection();

    @Override
    public int createShop(String string, String string1) {
        int idG=-1;
        try(PreparedStatement upitGrad=conn.prepareStatement("SELECT IdG FROM Grad WHERE Naziv=?")){ 
            upitGrad.setString(1,string1);
            ResultSet u=upitGrad.executeQuery();
            if(u.next())idG=u.getInt(1);
            
            try(PreparedStatement upitDodaj=conn.prepareStatement("INSERT INTO Prodavnica(Naziv,IdG) VALUES(?,?)")){
                upitDodaj.setString(1,string);
                upitDodaj.setInt(2,idG);
                upitDodaj.execute();
                
                try(PreparedStatement upitId=conn.prepareStatement("SELECT MAX(IDP) FROM Prodavnica")){ 
                   ResultSet u1=upitId.executeQuery();
                     int i=-1;
                    if(u1.next()) i=u1.getInt(1);
                    try(PreparedStatement ps=conn.prepareStatement("Insert into Racun VALUES(0)")){ 
                        ps.execute();
                        int maxId=-1;
                        try(PreparedStatement max=conn.prepareStatement("SELECT MAX(IDRAC) FROM RACUN")){ 
                            ResultSet s=max.executeQuery();
                            if(s.next()){ 
                                maxId=s.getInt(1);
                                
                                try(PreparedStatement dodaj=conn.prepareStatement("Insert into RACUNPRODAVNICA(IdP,IdRac) VALUES(?,?)") ){ 
                                    dodaj.setInt(1,i);
                                    dodaj.setInt(2,maxId);
                                    dodaj.execute();
                                }
                                return i;
                            }
                        }
                    }
                }
                
            }
            
            
        }
        catch(SQLException ex){
               Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }

    @Override
    public int setCity(int i, String string) {
       boolean flag=true;
         try(PreparedStatement upitPostavi=conn.prepareStatement("UPDATE Prodavnica SET IdG=(select idg from grad where Naziv=?) WHERE IdP=?")){ 
             upitPostavi.setInt(2,i);
             upitPostavi.setString(1, string);
             
              upitPostavi.execute();
              
             
         }
         catch(SQLException ex){
               flag=false;
               Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
          }
         if(!flag)return -1;
         return 1;
    }

    @Override
    public int getCity(int i) {
         try(PreparedStatement upitGrad=conn.prepareStatement("SELECT IdG FROM Prodavnica WHERE IdP=?")){ 
          upitGrad.setInt(1, i);
          
          ResultSet gradovi=upitGrad.executeQuery();
          if(gradovi.next()){ 
              return gradovi.getInt(1);
          }
      }
      catch(SQLException ex){
               Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
      }
      
      return -1;
    }

    @Override
    public int setDiscount(int i, int i1) {
        try(PreparedStatement upitP=conn.prepareStatement("SELECT * FROM Popust WHERE IdP=?")){ 
            upitP.setInt(1, i);
            ResultSet u=upitP.executeQuery();
            if(u.next()){ 
                try(PreparedStatement azuriraj=conn.prepareStatement("UPDATE Popust SET Iznos=? WHERE IdP=?")){ 
                    azuriraj.setInt(1,i1);
                    azuriraj.setInt(2, i);
                    azuriraj.execute();
                }
                catch(SQLException ex){
                    Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{ 
                try(PreparedStatement dodaj=conn.prepareStatement("INSERT INTO Popust(iDp,iZNOS) VALUES(?,?)")){ 
                    dodaj.setInt(1,i);
                    dodaj.setInt(2, i1);
                    dodaj.execute();
                }
                catch(SQLException ex){
                    Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            return 1;
        }
        catch(SQLException ex){
            Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }

    @Override
    public int increaseArticleCount(int i, int i1) {
        try(PreparedStatement upitDodaj=conn.prepareStatement("UPDATE ARTIKAL SET Kolicina+=? WHERE IdA=?")){ 
            upitDodaj.setInt(1,i1);
            upitDodaj.setInt(2,i);
            upitDodaj.execute();
            try(PreparedStatement upitCount=conn.prepareStatement("SELECT Kolicina from Artikal where IdA=?")){ 
                upitCount.setInt(1, i);
                ResultSet u=upitCount.executeQuery();
                if(u.next())return u.getInt(1);
            }
             catch(SQLException ex){
                  Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
             }
        }
        catch(SQLException ex){
             Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }

    @Override
    public int getArticleCount(int i) {
       try(PreparedStatement upitCount=conn.prepareStatement("SELECT Kolicina from Artikal where IdA=?")){ 
           upitCount.setInt(1, i);
           ResultSet u=upitCount.executeQuery();
           if(u.next())return u.getInt(1);
       }
       catch(SQLException ex){
            Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }

    @Override
    public List<Integer> getArticles(int i) {
        List<Integer>ids=new ArrayList<>();
        try(PreparedStatement upitArt=conn.prepareStatement("SELECT IdA FROM Artikal WHERE IdP=?" )){ 
                upitArt.setInt(1, i);
                ResultSet u=upitArt.executeQuery();
                while(u.next()){ 
                    ids.add(u.getInt(1));
                }
                return ids;
        }
        catch(SQLException ex){
               Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public int getDiscount(int i) {
        try(PreparedStatement upitPop=conn.prepareStatement("SELECT Iznos FROM Popust WHERE IdP=?")){ 
            upitPop.setInt(1,i);
            ResultSet p=upitPop.executeQuery();
            if(p.next()){ 
                return p.getInt(1);
            }
            
        }
        catch(SQLException ex){
            Logger.getLogger(ca200513_ShopOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }
    
}

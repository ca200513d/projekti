/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
// */
package rs.etf.sab.student;

import rs.etf.sab.operations.ArticleOperations;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user2
 */
public class ca200513_ArticleOperations implements ArticleOperations {
    @Override
    public int createArticle(int shopId, String articleName, int articlePrice) {
        Connection conn = DB.getInstance().getConnection();
        try(PreparedStatement upit=conn.prepareStatement("INSERT INTO Artikal(IdP,Ime,Cena,Kolicina) VALUES(?,?,?,0) ")){ 
            upit.setInt(1,shopId);
            upit.setString(2,articleName);
            upit.setInt(3,articlePrice);
            upit.execute();
            
            try(PreparedStatement upitId=conn.prepareStatement("SELECT MAX(IDA) FROM ARTIKAL")){ 
                ResultSet u=upitId.executeQuery();
                if(u.next())return u.getInt(1);
            }
            catch(SQLException ex){
            Logger.getLogger(ca200513_ArticleOperations.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        catch(SQLException ex){
            Logger.getLogger(ca200513_ArticleOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
        
    }
    
}

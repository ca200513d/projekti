/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.CityOperations;

/**
 *
 * @author user2
 */
public class ca200513_CityOperations implements CityOperations {

    @Override
    public int createCity(String string) {
        
        Connection conn = DB.getInstance().getConnection();
        try(Statement p=conn.createStatement();){ 
            ResultSet rss=p.executeQuery("SELECT Naziv FROM Grad");
            while(rss.next()){ 
                if(rss.getString(1).equals(string))return -1;
            }
            try(PreparedStatement ps=conn.prepareStatement("INSERT INTO Grad(Naziv)VALUES(?)",PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, string);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            rs.next();
            return rs.getInt(1);
            
           } catch (SQLException ex) {
                Logger.getLogger(ca200513_CityOperations.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        catch(SQLException ex){ 
            Logger.getLogger(ca200513_CityOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
        
    }

    @Override
    public List<Integer> getCities() {
        Connection conn = DB.getInstance().getConnection();
        List<Integer>ids=new ArrayList<>();
        Statement s;
        try {
            s = conn.createStatement();
            ResultSet rs=s.executeQuery("SELECT IdG FROM Grad");
            while(rs.next()){ 
                ids.add(rs.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ca200513_CityOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ids;
        
    }

    @Override
    public int connectCities(int i, int i1, int i2) {
       Connection conn = DB.getInstance().getConnection();
       try(PreparedStatement upitSpojeni=conn.prepareStatement("INSERT INTO LINIJA(IdG1,IdG2,PotrebnoDana) VALUES(?,?,?) ")){
           upitSpojeni.setInt(1,i);
           upitSpojeni.setInt(2,i1);
           upitSpojeni.setInt(3,i2);
           
           upitSpojeni.execute();
           
           try(PreparedStatement upitId=conn.prepareStatement("SELECT MAX(IdL) FROM Linija")){ 
               ResultSet u=upitId.executeQuery();
               if(u.next())return u.getInt(1);
           }
           catch(SQLException ex){ 
               Logger.getLogger(ca200513_CityOperations.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
       catch (SQLException ex) {
            Logger.getLogger(ca200513_CityOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       return -1;
    }

    @Override
    public List<Integer> getConnectedCities(int i) {
        Connection conn = DB.getInstance().getConnection();
        List<Integer>ids=new ArrayList<>();
         try(PreparedStatement upitPov=conn.prepareStatement("SELECT IdG1,IdG2 from Linija  WHERE IdG1=? OR IdG2=?")){ 
            upitPov.setInt(1, i);
            upitPov.setInt(2, i);
            ResultSet u=upitPov.executeQuery();
            while(u.next()){ 
                int idG1=u.getInt(1);
                int idG2=u.getInt(2);
                if(i==idG1)ids.add(idG2);
                else ids.add(idG1);
            }
            return ids;
            
        }
        catch (SQLException ex) {
            Logger.getLogger(ca200513_CityOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public List<Integer> getShops(int i) {
        Connection conn = DB.getInstance().getConnection();
        List<Integer>ids=new ArrayList<>();
        
        try(PreparedStatement upitProd=conn.prepareStatement("SELECT IdP from Prodavnica WHERE IdG=?")){ 
            upitProd.setInt(1, i);
            ResultSet u=upitProd.executeQuery();
            while(u.next()){ 
                ids.add(u.getInt(1));
            }
            return ids;
            
        }
        catch (SQLException ex) {
            Logger.getLogger(ca200513_CityOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}

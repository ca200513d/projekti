package rs.etf.sab.student;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user2
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
public class DB {
    
    private static final String username="sa";
    private static final String password="123";
    private static final String db="KurirskaSluzba";
    private static final int port=1433;
    private static final String server="localhost";
    
    String connectionUrl="jdbc:sqlserver://"+server+":"+port+";encrypt=true;trustServerCertificate=true;databaseName="+db;
    
    {
        
    System.out.println(connectionUrl);
    }
    
    private static DB database;//ovo je da bismo dobili singletone 
    
    public static DB getInstance(){ 
        if(database==null)database=new DB();
        return database;
    }
    private Connection connection;
    private DB(){
        try {
            connection=DriverManager.getConnection(connectionUrl, username, password);
        } catch (SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        }
    } //singletone
    
    public Connection getConnection(){ 
        return connection;
    }
}

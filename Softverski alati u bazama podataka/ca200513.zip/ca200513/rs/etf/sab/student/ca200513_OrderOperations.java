  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.GeneralOperations;
import rs.etf.sab.operations.OrderOperations;

/**
 *
 * @author user2
 */
public class ca200513_OrderOperations implements OrderOperations{

    private Connection conn = DB.getInstance().getConnection();
    private GeneralOperations g;
    
    public ca200513_OrderOperations(GeneralOperations g){ 
        this.g=g;
    }
            
    @Override
    public int addArticle(int i, int i1, int i2) {
        if(i2<=0)return -1;
        if(i1<=0 && i<=0)return -1;
        boolean ima=false;
        boolean poslata=false;
        try(PreparedStatement upitStatus=conn.prepareStatement("SELECT STATUS FROM PORUDZBINA WHERE IDPOR=?")){ 
            upitStatus.setInt(1,i);
            ResultSet r=upitStatus.executeQuery();
            if(r.next()){ 
                if(r.getInt(1)!=0)poslata=true;
            }
        }
        catch (SQLException ex) {
          Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(poslata){ 
            
            return -1;
        }
        try(PreparedStatement upitIma=conn.prepareStatement("SELECT * FROM ARTIKAL WHERE KOLICINA>=? AND IDA=?")){ 
                     upitIma.setInt(1,i2);
                     upitIma.setInt(2,i1);
                     
                     ResultSet s=upitIma.executeQuery();
                     if(s.next())ima=true;
        }
        catch (SQLException ex) {
           Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
         }
        if(!ima){ 
           
            return -1;
        }//nema u dovoljnoj kolicini
        try(PreparedStatement upitNadji=conn.prepareStatement("SELECT * FROM Sadrzi WHERE IdPor=? and IdA=?")){ 
             upitNadji.setInt(1,i);
             upitNadji.setInt(2,i1);
             
             ResultSet u=upitNadji.executeQuery();
             if(u.next()){ 
                 try(PreparedStatement azuriraj=conn.prepareStatement("UPDATE Sadrzi SET Kolicina=Kolicina+? WHERE IdPor=? and IdA=?")){ 
                     azuriraj.setInt(1,i2);
                     azuriraj.setInt(2, i);
                     azuriraj.setInt(3,i1);
                     
                     azuriraj.execute();
                 }
                 catch (SQLException ex) {
                    Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
                  }
             }
             else{ 
                  try(PreparedStatement dodaj=conn.prepareStatement("INSERT INTO Sadrzi(IdPor,IdA,Kolicina) VALUES(?,?,?)")){ 
                     dodaj.setInt(1, i);
                     dodaj.setInt(2,i1);
                     dodaj.setInt(3,i2);
                     
                     dodaj.execute();
                 }
                 catch (SQLException ex) {
                    Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
                  }
             }
             try(PreparedStatement upitSmanji=conn.prepareStatement("UPDATE ARTIKAL SET KOLICINA=KOLICINA-? WHERE IDA=?")){ 
                      upitSmanji.setInt(1,i2);
                      upitSmanji.setInt(2, i1);
                      
                      upitSmanji.execute();
             }
             catch (SQLException ex) {
                 Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
                 return -1;
             }
             try(PreparedStatement upitId=conn.prepareStatement("SELECT IDA FROM SADRZI WHERE IDPor=? AND IDA=?")){ 
                     upitId.setInt(1,i);
                     upitId.setInt(2,i1);
                     
                     ResultSet uu=upitId.executeQuery();
                     if(uu.next())return uu.getInt(1);
             }
            catch (SQLException ex) {
               Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
               return -1;
             }
        }
        catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }

    @Override
    public int removeArticle(int i, int i1) {
       if(i1<=0 && i<=0)return -1;
       int broj=-1;
       boolean poslata=false;
        try(PreparedStatement upitStatus=conn.prepareStatement("SELECT STATUS FROM PORUDZBINA WHERE IDPOR=?")){ 
            upitStatus.setInt(1,i);
            ResultSet r=upitStatus.executeQuery();
            if(r.next()){ 
                if(r.getInt(1)!=0)poslata=true;
            }
        }
        catch (SQLException ex) {
          Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(poslata)return -1;
       try(PreparedStatement upit2=conn.prepareStatement("SELECT Kolicina FROM Sadrzi WHERE IdPor=? and IdA=?")){ 
            upit2.setInt(1,i);
            upit2.setInt(2,i1);
            ResultSet s=upit2.executeQuery();
            if(s.next())broj=s.getInt(1);
       }
       catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       try(PreparedStatement upit=conn.prepareStatement("DELETE FROM Sadrzi WHERE IdPor=? and IdA=?")){ 
           upit.setInt(1,i);
           upit.setInt(2,i1);
           upit.execute();
           
       }
       catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       try(PreparedStatement upit1=conn.prepareStatement("UPDATE Artikal SET Kolicina=Kolicina+1 WHERE IdA=?")){ 
           upit1.setInt(1,i1);
           
           upit1.execute();
           
           return 1; 
       }
       catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       return -1;
    }

    @Override
    public List<Integer> getItems(int i) {
       if(i<0)return null;
       List<Integer>ids=new ArrayList<>();
       try(PreparedStatement upit=conn.prepareStatement("SELECT IdA FROM Sadrzi WHERE IdPor=?")){ 
           upit.setInt(1, i);
           ResultSet u=upit.executeQuery();
           while(u.next()){ 
               ids.add(u.getInt(1));
           }
           return ids;
       }
       catch (SQLException ex) {
           Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }

    @Override
    public int completeOrder(int i) {
       if(i<0)return -1;
        //OVDE TREBA JOS PORVJERITI DA LI IMA DOVOLJNO NOVCA PA AKO NEMA VRATITI -1
        BigDecimal cijena=getFinalPrice(i);
        BigDecimal novac;//koliko on ima na racunu
        try(PreparedStatement ps=conn.prepareStatement("SELECT r.Iznos FROM RACUNKUPAC RK JOIN RACUN R ON RK.IDRAC=R.IDRAC,PORUDZBINA P WHERE P.IDPOR=? AND P.IDK=RK.IDK") ){ 
            ps.setInt(1,i);
            ResultSet u=ps.executeQuery();
            if(u.next()){ 
                novac=u.getBigDecimal(1).setScale(3);
                if(novac.compareTo(cijena)==-1)return -1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        boolean poslata=false;
        try(PreparedStatement upitStatus=conn.prepareStatement("SELECT STATUS FROM PORUDZBINA WHERE IDPOR=?")){ 
            upitStatus.setInt(1,i);
            ResultSet r=upitStatus.executeQuery();
            if(r.next()){ 
                if(r.getInt(1)!=0)poslata=true;
            }
        }
        catch (SQLException ex) {
          Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(poslata)return -1;
        
       int idNajblizi=dijkstra(i);
      
       try(PreparedStatement upitPor=conn.prepareStatement("UPDATE Porudzbina SET IdG=?,Status=1,VrijemePoslata=? WHERE IdPor=?")){ 
           upitPor.setInt(1,idNajblizi);
           
           upitPor.setDate(2,new Date(g.getCurrentTime().getTimeInMillis()));
           upitPor.setInt(3,i);
           upitPor.execute();//postavljen je grad u kome treba biti porudzbina
           
           //sada treba izracunati koliko dana je potrebno da stignu svi artikli do te prod
           int maxDana=maxBrDana(i);
           //ako je vraceno -3,mijenjaj status u 3
           
            if(maxDana==-3){ 
                try(PreparedStatement mijenjajGrad=conn.prepareStatement("UPDATE Porudzbina SET Vrijeme=0,Status=3,VrijemePrimljena=? WHERE IdPor=?")){ 
               
                    mijenjajGrad.setInt(2,i);

                    mijenjajGrad.setDate(1,new Date(g.getCurrentTime().getTimeInMillis()));
                    mijenjajGrad.execute();

                }
                catch (SQLException ex) {
                    Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
                }
                return 1;
           }
           //ako je vraceno -2 mijenjaj status u 2
           if(maxDana==-2){ 
               try(PreparedStatement upitStatus=conn.prepareStatement("UPDATE Porudzbina SET Vrijeme=0,Status=2 WHERE IdPor=?")){ 
                       
                    upitStatus.setInt(1,i);
                    
                    upitStatus.execute();

                }catch (SQLException ex) {
                     Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
               }
               return 1;
           }
           //to postaviti na porudzbinu
           try(PreparedStatement upitDodajVrijeme=conn.prepareStatement("UPDATE Porudzbina SET Vrijeme=? WHERE IdPor=?")){ 
               upitDodajVrijeme.setInt(1,maxDana);
               upitDodajVrijeme.setInt(2,i);
               upitDodajVrijeme.execute();
               return 1;
           }
           catch (SQLException ex) {
             Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           
       }
       catch (SQLException ex) {
           Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
       }
       return -1;
    }

    @Override
    public BigDecimal getFinalPrice(int i) {
         if(i<0)return new BigDecimal("0").setScale(3);
        try(CallableStatement pc= conn.prepareCall("exec dbo.SP_FINAL_PRICE ?,?,?")){ 
            pc.setInt(1,i);
            pc.setDate(2,new Date(g.getCurrentTime().getTimeInMillis()));
            
            pc.registerOutParameter(3,Types.DECIMAL);
            
            pc.execute();
            
            BigDecimal ukCijena=pc.getBigDecimal(3);
            return ukCijena.setScale(3);
        }    
        catch (SQLException ex) {
           Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
       }
       return  new BigDecimal("0").setScale(3);
    }

    @Override
    public BigDecimal getDiscountSum(int i) {
        if(i<0)return  new BigDecimal("0").setScale(3);
         try(CallableStatement pc= conn.prepareCall("exec dbo.SP_FINAL_PRICE ?,?,?")){ 
            pc.setInt(1,i);
            pc.setDate(2,new Date(g.getCurrentTime().getTimeInMillis()));
            
            pc.registerOutParameter(3,Types.DECIMAL);
            
            pc.execute();
            
            BigDecimal ukCijena=pc.getBigDecimal(3);
            
            try(CallableStatement pc1=conn.prepareCall("exec dbo.SP_FINAL_PRICE1 ?,?")){ 
                pc1.setInt(1,i);
               

                pc1.registerOutParameter(2,Types.DECIMAL);

                pc1.execute();

                BigDecimal ukCijena1=pc1.getBigDecimal(2);
                
                return ukCijena1.subtract(ukCijena).setScale(3);
                
            }catch (SQLException ex) {
                Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
        catch (SQLException ex) {
           Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
       }
       return  new BigDecimal("0").setScale(3);
    }

    @Override
    public String getState(int i) {
        if(i<0)return null;
        try(PreparedStatement upitK=conn.prepareStatement("SELECT Status from Porudzbina where IdPor=?")){ 
           upitK.setInt(1,i);
           ResultSet u=upitK.executeQuery();
           if(u.next()){ 
               int broj=u.getInt(1);
               switch(broj){ 
                   case 0: return "created";
                   case 1: case 2: return "sent";
                   case 3: return "arrived";
               }
           }
       }
       catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    
    }

    @Override
    public Calendar getSentTime(int i) {
        if(i<0)return null;
        try(PreparedStatement upitSent=conn.prepareStatement("SELECT VrijemePoslata FROM Porudzbina where IdPor=?")){ 
            upitSent.setInt(1, i);
            
            ResultSet u=upitSent.executeQuery();
            if(u.next()){ 
                Calendar cal=Calendar.getInstance();
                Date date=u.getDate(1);
                if(date==null)return null;
                cal.setTimeInMillis( date.getTime());
                return cal;
            }
        }
        catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public Calendar getRecievedTime(int i) {
           if(i<0)return null;
           try(PreparedStatement upitSent=conn.prepareStatement("SELECT VrijemePrimljena FROM Porudzbina where IdPor=?")){ 
            upitSent.setInt(1, i);
            
            ResultSet u=upitSent.executeQuery();
            if(u.next()){ 
                Calendar cal=Calendar.getInstance();
                Date date=u.getDate(1);
                if(date==null)return null;
                cal.setTimeInMillis( date.getTime());
                return cal;
            }
        }
        catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public int getBuyer(int i) {
        if(i<0)return -1;
       try(PreparedStatement upitK=conn.prepareStatement("SELECT  IdK from Porudzbina where IdPor=?")){ 
           upitK.setInt(1,i);
           ResultSet u=upitK.executeQuery();
           if(u.next())return u.getInt(1);
       }
       catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       return -1;
    }

    @Override
    public int getLocation(int i) {
        if(i<0)return -1;
       try(PreparedStatement upitK=conn.prepareStatement("SELECT  IdG from Porudzbina where IdPor=? and Status>0")){ 
           upitK.setInt(1,i);
           ResultSet u=upitK.executeQuery();
           if(u.next())return u.getInt(1);
       }
       catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       return -1;
    }
    
    private int dijkstra(int i){
	int idG=-1;
	//trazim grad u kome je kupac
	try(PreparedStatement upitMojGrad=conn.prepareStatement("SELECT K.IdG FROM Kupac K JOIN Porudzbina P ON P.IdK=K.IdK WHERE P.IdPor=?")){ 
		upitMojGrad.setInt(1,i);
		ResultSet a=upitMojGrad.executeQuery();
		if(a.next())idG=a.getInt(1);
	}
	catch (SQLException ex) {
        Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        //ako dati grad ima prodavnicu vrati njega 
        try(PreparedStatement upitProd=conn.prepareStatement("SELECT * FROM Prodavnica WHERE IdG=?")){ 
            upitProd.setInt(1,idG);
            ResultSet prod=upitProd.executeQuery();
            if(prod.next())return idG;
        }
        catch (SQLException ex) {
        Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
	int brGradova=-1;
        HashMap<Integer,Integer>mapaRastojanja=new HashMap<>();
        List<Integer>idGrad=new ArrayList<>();
	//prebrojim sve gradove,osim onog u kome je kupac
	try(PreparedStatement upitBrojGradova=conn.prepareStatement("SELECT COUNT(*) FROM GRAD")){ 
		ResultSet u=upitBrojGradova.executeQuery();
		if(u.next())brGradova=u.getInt(1)-1;
		
		//sve idG osim onog u kome je kupac smjestim u listu i hash mapu
		try(PreparedStatement upitGrad=conn.prepareStatement("SELECT IdG FROM Grad WHERE IdG<>?")){
			upitGrad.setInt(1,idG);
			ResultSet uu=upitGrad.executeQuery();
			while(uu.next()){ 
				int broj=uu.getInt(1);
				idGrad.add(broj);
				mapaRastojanja.put(broj,(int)Double.POSITIVE_INFINITY);
			}
		}
                catch (SQLException ex) {
                    Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
                }
        
		
                for(int id:idGrad){
			//ovde u hash mapu dodajemo za direktno povezane gradove rastojanja
			try(PreparedStatement upitLinija=conn.prepareStatement("SELECT PotrebnoDana FROM Linija where (IdG1=? and IdG2=?) or (IdG1=? and IdG2=?)")){ 
				upitLinija.setInt(1,idG);
				upitLinija.setInt(2,id);
				upitLinija.setInt(3,id);
				upitLinija.setInt(4,idG);
				
				ResultSet aa=upitLinija.executeQuery();
				if(aa.next())mapaRastojanja.put(id,aa.getInt(1)); //postavi rastojanje 
			}
			catch (SQLException ex) {
				Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
			}
		} 
		//sada trazimo min rastojanje,i za sve gradove koji su na tom putu postavlajmo novo rastojanje
		int minRast=(int)Double.POSITIVE_INFINITY;
		int idMinRast=-1;
                
		for(int ii=0;ii<brGradova;ii++){ 
                    
			int idd=imaMinRastojanje(mapaRastojanja,idGrad);
                        
			int rastojanje=mapaRastojanja.get(idd);
			if(rastojanje<minRast){ 
                            //provjeravam da li postojiprodavnica u datom gradu,ako da onda ga stavim kao min 
				try(PreparedStatement upitProd=conn.prepareStatement("SELECT * FROM Prodavnica WHERE IdG=?")){ 
					upitProd.setInt(1,idd);
					ResultSet e=upitProd.executeQuery();
					if(e.next()){ //postavlja novi najblizi grad sa prodavnicom
						minRast=rastojanje;
						idMinRast=idd;
					}
				}
				catch (SQLException ex) {
					Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
                        //da li se rastojanje preostalih gradova moze smanjiti preko trenutno najmanjeg rastojanja
			for(int id:idGrad){
				if(id==idd)continue;
				int rastojanje2=mapaRastojanja.get(id);//rastojanje od naseg grada 
				try(PreparedStatement upitLinija=conn.prepareStatement("SELECT PotrebnoDana FROM Linija where (IdG1=? and IdG2=?) or (IdG1=? and IdG2=?)")){ 
					upitLinija.setInt(1,idd);
					upitLinija.setInt(2,id);
					upitLinija.setInt(3,id);
					upitLinija.setInt(4,idd);
					
					ResultSet aa=upitLinija.executeQuery();
					if(aa.next()){
						int broj=aa.getInt(1);
						if(broj+rastojanje<rastojanje2){ 
							mapaRastojanja.put(id,broj+rastojanje);
						}
						
					}
				}
				catch (SQLException ex) {
					Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
				}
				
				
		}
                        mapaRastojanja.put(idd,-1);
                }
                
		return idMinRast;
	}
        
	catch (SQLException ex) {
        Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
    }

	return -1;
}

    private int imaMinRastojanje(HashMap<Integer,Integer>rastojanja,List<Integer>gradovi){ 
            int min=(int)Double.POSITIVE_INFINITY;
            int idd=-1;
            
            for(int id:gradovi){ 
            
                    if(rastojanja.get(id)<min && rastojanja.get(id)!=-1){ 
                            min=rastojanja.get(id);
                            idd=id;
                    }
                    
            }
            if(idd==-1 && !gradovi.isEmpty())idd=gradovi.get(0);
            return idd;
    }
    
    private int maxBrDana(int i){ 
        int idG=-1;
	//trazim grad u kome je porudzbina
	try(PreparedStatement upitMojGrad=conn.prepareStatement("SELECT IdG FROM Porudzbina WHERE IdPor=?")){ 
		upitMojGrad.setInt(1,i);
		ResultSet a=upitMojGrad.executeQuery();
		if(a.next())idG=a.getInt(1);
                
	}
	catch (SQLException ex) {
        Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }

	int brGradova=-1;
        HashMap<Integer,Integer>mapaRastojanja=new HashMap<>();
        List<Integer>idGrad=new ArrayList<>();
	//prebrojim sve gradove,osim onog u kome je porudzbina
	try(PreparedStatement upitBrojGradova=conn.prepareStatement("SELECT COUNT(*) FROM GRAD")){ 
		ResultSet u=upitBrojGradova.executeQuery();
		if(u.next())brGradova=u.getInt(1)-1;
		
		//sve idG osim onog u kome je porudzbina smjestim u listu i hash mapu
		try(PreparedStatement upitGrad=conn.prepareStatement("SELECT IdG FROM Grad WHERE IdG<>?")){
			upitGrad.setInt(1,idG);
			ResultSet uu=upitGrad.executeQuery();
			while(uu.next()){ 
				int broj=uu.getInt(1);
				idGrad.add(broj);
				mapaRastojanja.put(broj,(int)Double.POSITIVE_INFINITY);
			}
		}
                catch (SQLException ex) {
                    Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
                }
        
		
                for(int id:idGrad){
			//ovde u hash mapu dodajemo za direktno povezane gradove rastojanja
			try(PreparedStatement upitLinija=conn.prepareStatement("SELECT PotrebnoDana FROM Linija where (IdG1=? and IdG2=?) or (IdG1=? and IdG2=?)")){ 
				upitLinija.setInt(1,idG);
				upitLinija.setInt(2,id);
				upitLinija.setInt(3,id);
				upitLinija.setInt(4,idG);
				
				ResultSet aa=upitLinija.executeQuery();
				if(aa.next())mapaRastojanja.put(id,aa.getInt(1)); //postavi rastojanje 
			}
			catch (SQLException ex) {
				Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
			}
		} 
		//sada trazimo min rastojanje,i za sve gradove koji su na tom putu postavlajmo novo rastojanje

		for(int ii=0;ii<brGradova;ii++){ 
			int idd=imaMinRastojanje(mapaRastojanja,idGrad);
			int rastojanje=mapaRastojanja.get(idd);
			idGrad.remove((Integer)idd);
			for(int id:idGrad){
				int rastojanje2=mapaRastojanja.get(id);//rastojanje od naseg grada 
				try(PreparedStatement upitLinija=conn.prepareStatement("SELECT PotrebnoDana FROM Linija where (IdG1=? and IdG2=?) or (IdG1=? and IdG2=?)")){ 
					upitLinija.setInt(1,idd);
					upitLinija.setInt(2,id);
					upitLinija.setInt(3,id);
					upitLinija.setInt(4,idd);
					
					ResultSet aa=upitLinija.executeQuery();
					if(aa.next()){
						int broj=aa.getInt(1);
						if(broj+rastojanje<rastojanje2){ 
							mapaRastojanja.put(id,broj+rastojanje);
						}
						
					}
				}
				catch (SQLException ex) {
					Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
				}
				
				
                        }
                        
                }
		//sada su sracunata min rastojanja i potrebno je za gradove u kojima su artikli naci najvece rastojanje
                List<Integer>gradovi=odrediGradoveArtikala(i,idG);
                
                //ako se vrati prazna lista,znaci da su svi artikli u 1 gradu,pa treba odmah promjeniti status u 2
                if(gradovi.isEmpty()){ 
                    //sad provjeri je l to i grad kupca,pa ako jeste status=3
                    int idG1=-1;
                    try(PreparedStatement getCity=conn.prepareStatement("select k.idg from kupac k join porudzbina p on k.idk=p.idk WHERE IDPOR=?")){ 
                        getCity.setInt(1,i);
                        ResultSet v=getCity.executeQuery();
                        if(v.next())idG1=v.getInt(1);
                        
                        if(idG==idG1)return -3;
                    
                    }   catch (SQLException ex) {
                        Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    return -2;
                }
                
                int maxRastojanje=(int)Double.NEGATIVE_INFINITY;
                for(int id:gradovi){
                    if(id==idG)continue; //jer grad u kome je porudzbina moze biti grad u kome je artikal :)))
                   
                    int rastojanje=mapaRastojanja.get(id);
                    
                    if(rastojanje>maxRastojanje)maxRastojanje=rastojanje;
                }
                return maxRastojanje;
	}
        
	catch (SQLException ex) {
        Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
    }

	return -1;
    }
    
    private List<Integer> odrediGradoveArtikala(int i,int grad){ 
        try(PreparedStatement upitGradovi=conn.prepareStatement("SELECT P.IdG FROM Sadrzi S JOIN Artikal A ON A.IdA=S.IdA JOIN Prodavnica P ON P.IdP=A.IdP WHERE S.IdPor=? and P.idG<>?")){ 
            upitGradovi.setInt(1, i);
            upitGradovi.setInt(2,grad);
            ResultSet u=upitGradovi.executeQuery();
            List<Integer> gradovi=new ArrayList<>();
            while(u.next()){ 
                gradovi.add(u.getInt(1));
            }
            return gradovi;
        }
        catch (SQLException ex) {
            Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}


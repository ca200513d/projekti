/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.TransactionOperations;

/**
 *
 * @author user2
 */
public class ca200513_TransactionOperations implements TransactionOperations{

    private Connection conn = DB.getInstance().getConnection();
    
    @Override
    public BigDecimal getBuyerTransactionsAmmount(int i) {
      try(PreparedStatement upitKupac=conn.prepareStatement("SELECT coalesce(SUM(T.Cena),0) FROM Transakcija T JOIN RacunKupac K on K.IdRac=T.IdRac WHERE K.IdK=?")){ 
          upitKupac.setInt(1,i);
          
          ResultSet u=upitKupac.executeQuery();
          if(u.next()){ 
              return u.getBigDecimal(1);
          }
      } catch (SQLException ex) {
            Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
      return new BigDecimal("0").setScale(3);
    }

    @Override
    public BigDecimal getShopTransactionsAmmount(int i) {
       try(PreparedStatement upitKupac=conn.prepareStatement("SELECT coalesce(SUM(T.Cena),0) FROM Transakcija T JOIN RacunProdavnica K on K.IdRac=T.IdRac WHERE K.Idp=?")){ 
          upitKupac.setInt(1,i);
          
          ResultSet u=upitKupac.executeQuery();
          if(u.next()){ 
              return u.getBigDecimal(1);
          }
      } catch (SQLException ex) {
            Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
      return new BigDecimal("0").setScale(3);
    }

    @Override
    public List<Integer> getTransationsForBuyer(int i) {
      try(PreparedStatement upitTrans=conn.prepareStatement("SELECT T.IdT FROM Transakcija T JOIN RACUNKUPAC K ON K.IDRAC=T.IDRAC WHERE K.IDK=?")){ 
          upitTrans.setInt(1, i);
          
          ResultSet u=upitTrans.executeQuery();
          
          List<Integer>lista=new ArrayList<>();
          while(u.next()){ 
              lista.add(u.getInt(1));
          }
          return lista;
      }
      catch (SQLException ex) {
        Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
       }
      return null;
    }

    @Override
    public int getTransactionForBuyersOrder(int i) {
        try(PreparedStatement ps=conn.prepareStatement("SELECT IdT FROM Transakcija WHERE IdPor=?")){ 
            ps.setInt(1,i);
            ResultSet u=ps.executeQuery();
            if(u.next())return u.getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
        
    }

    @Override
    public int getTransactionForShopAndOrder(int i, int i1) {
       try(PreparedStatement ps=conn.prepareStatement("SELECT T.IdT FROM Transakcija T JOIN RacunProdavnica P ON T.IdRac=P.IdRac WHERE P.IdP=? and T.IdPor=?")){ 
           ps.setInt(1, i1);
           ps.setInt(2,i);
           
           ResultSet u=ps.executeQuery();
           if(u.next())return u.getInt(1);
       } catch (SQLException ex) {
            Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       return -1;
    }

    @Override
    public List<Integer> getTransationsForShop(int i) {
        try(PreparedStatement upitTrans=conn.prepareStatement("SELECT T.IdT FROM Transakcija T JOIN RACUNprodavnica K ON K.IDRAC=T.IDRAC WHERE k.IDp=?")){ 
          upitTrans.setInt(1, i);
          
          ResultSet u=upitTrans.executeQuery();
          
          List<Integer>lista=new ArrayList<>();
          while(u.next()){ 
              lista.add(u.getInt(1));
          }
          
          if(lista.size()==0)return null;
          return lista;
      }
        catch (SQLException ex) {
          Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
         }
        return null;
    }

    @Override
    public Calendar getTimeOfExecution(int i) {
       try(PreparedStatement ps=conn.prepareStatement("SELECT Vrijeme FROM TRANSAKCIJA WHERE IdT=?")){ 
           ps.setInt(1, i);
           ResultSet u=ps.executeQuery();
           if(u.next()){ 
              Calendar cal=Calendar.getInstance();
              cal.clear();
              cal.setTimeInMillis(u.getDate(1).getTime());
              return cal;
           }
       } catch (SQLException ex) {
            Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }

    @Override
    public BigDecimal getAmmountThatBuyerPayedForOrder(int i) {
        try(PreparedStatement ps=conn.prepareStatement("SELECT Cena From Transkacija WHERE IdPor=?")){ 
            ps.setInt(1,i);
            
            ResultSet u=ps.executeQuery();
            
            if(u.next())return u.getBigDecimal(1);
        } catch (SQLException ex) {
            Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new BigDecimal("0").setScale(3);
    }

    @Override
    public BigDecimal getAmmountThatShopRecievedForOrder(int i, int i1) {
         try(PreparedStatement ps=conn.prepareStatement("SELECT T.Cena From Transakcija T JOIN RacunProdavnica P ON T.IdRac=P.IdRac WHERE T.IdPor=? AND P.IdP=?")){ 
            ps.setInt(1,i1);
            ps.setInt(2,i);
            ResultSet u=ps.executeQuery();
            
            if(u.next())return u.getBigDecimal(1);
        } catch (SQLException ex) {
            Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new BigDecimal("0").setScale(3);
    }

    @Override
    public BigDecimal getTransactionAmount(int i) {
        try(PreparedStatement ps=conn.prepareStatement("SELECT Cena FROM Transakcija WHERE IdT=?")){ 
            ps.setInt(1, i);
            ResultSet u=ps.executeQuery();
            if(u.next())return u.getBigDecimal(1);
        } catch (SQLException ex) {
            Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new BigDecimal("0").setScale(3);
    }

    @Override
    public BigDecimal getSystemProfit() {
        try(PreparedStatement ps=conn.prepareStatement("SELECT Profit FROM Sistem WHERE IdS=1")){ 
            ResultSet u=ps.executeQuery();
            if(u.next())return u.getBigDecimal(1);
        } catch (SQLException ex) {
            Logger.getLogger(ca200513_TransactionOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new BigDecimal("0").setScale(3);
    }
    
}

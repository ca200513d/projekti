/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.GeneralOperations;

/**
 *
 * @author user2
 */
public class ca200513_GeneralOperations implements GeneralOperations {

    private Calendar cal;
    private Connection conn = DB.getInstance().getConnection();
    
    @Override
    public void setInitialTime(Calendar clndr) {
        cal=(Calendar) clndr.clone();
    }

    @Override
    public Calendar time(int i) {
        int vrati=0;
        if(i==0)return cal;
        cal.add(Calendar.DAY_OF_MONTH,i);
         //oni koji tek trebaju biti poslati
        try(PreparedStatement upitVrijeme=conn.prepareStatement("SELECT IdPor,Vrijeme FROM Porudzbina WHERE Status=1")){ 
            ResultSet u=upitVrijeme.executeQuery();
          
            while(u.next()){ 
               int idPor=u.getInt(1);
               int vrijeme=u.getInt(2);
               
               if(vrijeme-i<=0 && vrijeme!=-1){ //ako je proteklo to potrebno vrijeme,a porudzbina je gotova
                   
                   int tmp=i-vrijeme;//koliko se jos moze pomjeriti za poslato
                   int idg1=-1,idg2=-1;
                   try(PreparedStatement upit1=conn.prepareStatement("SELECT P.IdG,K.IdG FROM Porudzbina P JOIN Kupac K ON  K.IDK=P.IDK  WHERE IdPor=?")){
                       upit1.setInt(1,idPor);
                       ResultSet v=upit1.executeQuery();
                       if(v.next()){ 
                           idg1=v.getInt(1);
                           idg2=v.getInt(2);
                       }
                   }
                   if(idg1!=-1 && idg2!=-1 && idg1==idg2){ 
                            try(PreparedStatement mijenjajGrad=conn.prepareStatement("UPDATE Porudzbina SET Vrijeme=0,Status=3,VrijemePrimljena=? WHERE IdPor=?")){ 

                                mijenjajGrad.setInt(2,idPor);
                                mijenjajGrad.setDate(1,new Date(cal.getTimeInMillis()-tmp*86400000));
                                mijenjajGrad.execute();
                                    
                            }
                   }
                   else{ 
                           try(PreparedStatement upitStatus=conn.prepareStatement("UPDATE Porudzbina SET Vrijeme=?,Status=2,dohv=0 WHERE IdPor=?")){ 
                       
                                upitStatus.setInt(2,idPor);
                                upitStatus.setInt(1,tmp);
                                upitStatus.execute();
                               
                                

                            }catch (SQLException ex) {
                                 Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
                             }
                    }
               }
               else{ 
                   try(PreparedStatement azuriraj=conn.prepareStatement("UPDATE Porudzbina SET Vrijeme=Vrijeme-? WHERE IdPor=?")){ 
                       azuriraj.setInt(1,i);
                       azuriraj.setInt(2,idPor);
                       
                       azuriraj.execute();
                   }
                   catch (SQLException ex) {
                        Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
                    }
               }
            }
            
        }catch (SQLException ex) {
            Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        //pomjeranje onih koji su vec poslati
        try(PreparedStatement upit1=conn.prepareStatement("SELECT IDPOR,Vrijeme,dohv FROM PORUDZBINA WHERE STATUS=2")){ 
            
            ResultSet r=upit1.executeQuery(); //sve poslate porudzbine i nekima se treba promjeniti status
            int tmp;
            
            while(r.next()){
                if(i==0)i=vrati;
                int idPor=r.getInt(1);
                int flag=r.getInt(3);
                if(flag==0){ 
                    vrati=i;
                    i=0;
                    try(PreparedStatement ps=conn.prepareStatement("UPDATE Porudzbina SET dohv=1 WHERE idPor=?")){ 
                        ps.setInt(1,idPor);
                        ps.execute();
                    }
                    
                }
                tmp=r.getInt(2);//ako je neko vrijeme proteklo a nismo ga uracunali 
                
                try(PreparedStatement getCity=conn.prepareStatement("select k.idg from kupac k join porudzbina p on k.idk=p.idk WHERE IDPOR=?")){ 
                    getCity.setInt(1,idPor);
                    ResultSet u=getCity.executeQuery();
                    int idG1=-1;//grad gjde je kupac
                    if(u.next())idG1=u.getInt(1);
                    if(idG1==-1)continue;
                    List<Integer>gradovi=dijkstra(idPor,idG1);
                    
                    int idG=gradovi.get(0);//grad gdje je porudzbina
                    boolean mijenjaj=false;
                    int broj=i+tmp;//tmp jer je i toliko proteklo do sad,a nismo uracuali 
                   
                    if(broj==0)continue;
                    for(int j=1;j<gradovi.size();j++){ 
                        try(PreparedStatement upitLinija=conn.prepareStatement("SELECT PotrebnoDana FROM Linija where (IdG1=? and IdG2=?) or (IdG1=? and IdG2=?)")){ 
                            upitLinija.setInt(1,idG);
                            upitLinija.setInt(2,gradovi.get(j));
                            upitLinija.setInt(3,gradovi.get(j));
                            upitLinija.setInt(4,idG);
                            
                            ResultSet uu=upitLinija.executeQuery();
                            int rastojanje=-1;
                            if(uu.next()){ 
                                rastojanje=uu.getInt(1);
                            }
                            if(rastojanje==-1)break;
                            broj-=rastojanje;
                            //ovo znaci da se treba pomjeriti u taj grad 
                            idG=gradovi.get(j);
                           
                            if(broj>=0){ 
               
                                if(idG==idG1)mijenjaj=true;//znaci da je paket stigao 
                                if(!mijenjaj){ 
                                    try(PreparedStatement mijenjajGrad=conn.prepareStatement("UPDATE Porudzbina SET IdG=?,Vrijeme=? WHERE IdPor=?")){ 
                                        mijenjajGrad.setInt(1,idG);
                                        mijenjajGrad.setInt(3,idPor);
                                        mijenjajGrad.setInt(2,broj); //koliko je jos proslo 
                                        mijenjajGrad.execute();
                                    
                                    }
                                    catch (SQLException ex) {
                                        Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                                else{ 
                                    try(PreparedStatement mijenjajGrad=conn.prepareStatement("UPDATE Porudzbina SET IdG=?,Vrijeme=0,Status=3,VrijemePrimljena=? WHERE IdPor=?")){ 
                                        mijenjajGrad.setInt(1,gradovi.get(j));
                                        mijenjajGrad.setInt(3,idPor);
                                       
                                        mijenjajGrad.setDate(2,new Date(cal.getTimeInMillis()- broj*86400000));
                                        mijenjajGrad.execute();
                                    
                                    }
                                    catch (SQLException ex) {
                                        Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    break;
                                }
                                
                            }
                            else if(broj<0 && i!=0){ //znaci nije proteklo dovoljno dana da se predje u naredni grad,onda to pamtimo
                                try(PreparedStatement dodajVrijeme=conn.prepareStatement("UPDATE Porudzbina SET Vrijeme=? WHERE IdPor=?")){ 
                                    dodajVrijeme.setInt(2,idPor);
                                    
                                    dodajVrijeme.setInt(1,broj+rastojanje);
                                    dodajVrijeme.execute(); 
                                    
                                    
                                }
                                break;//zato sto ne moze prelaziti u naredne gradove sigurno,ako nije mogla u trenutni 
                            }
                        }
                        catch (SQLException ex) {
                            Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    
                }catch (SQLException ex) {
                        Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        }catch (SQLException ex) {
            Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return cal;
    }

    @Override
    public Calendar getCurrentTime() {
       return cal;
    }

    @Override
    public void eraseAll() {
       
        try (Statement s=conn.createStatement();){
            
            
            s.execute("delete from linija");
            s.execute("delete from sadrzi");
            s.execute("delete from racunKupac");
            s.execute("delete from racunProdavnica");
            s.execute("delete from transakcija");
            s.execute("delete from racun");
            s.execute("delete from porudzbina");
             s.execute("delete from kupac");
            s.execute("delete from artikal");
            s.execute("delete from popust");
            s.execute("delete from prodavnica");
            s.execute("delete from grad");
            s.execute("delete from sistem");
        } catch (SQLException ex) {
            Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    private class Node{ 
        int id; 
        int parent; //ko mu je roditeljski cvor 
        int rastojanje;
    }
    public List<Integer> dijkstra(int i,int id1){ 
        int idG=-1;
	//trazim grad u kome je porudzbina trenutno 
	try(PreparedStatement upitMojGrad=conn.prepareStatement("SELECT IdG FROM Porudzbina WHERE IdPor=?")){ 
		upitMojGrad.setInt(1,i);
		ResultSet a=upitMojGrad.executeQuery();
		if(a.next())idG=a.getInt(1);
	}
	catch (SQLException ex) {
            Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
       
	int brGradova=-1;
        HashMap<Integer,Node>mapaRastojanja=new HashMap<>();
        List<Integer>idGrad=new ArrayList<>();
	//prebrojim sve gradove,osim onog u kome je tenutno porudzbina
	try(PreparedStatement upitBrojGradova=conn.prepareStatement("SELECT COUNT(*) FROM GRAD")){ 
		ResultSet u=upitBrojGradova.executeQuery();
		if(u.next())brGradova=u.getInt(1)-1;
		
		//kreiram mapu cvorova i u svakom cvoru cuvam rastojanje do ovog iz porudzbine i ko mu je roditelj,preko koga dolazi do njega
		try(PreparedStatement upitGrad=conn.prepareStatement("SELECT IdG FROM Grad WHERE IdG<>?")){
			upitGrad.setInt(1,idG);
			ResultSet uu=upitGrad.executeQuery();
			while(uu.next()){ 
				int broj=uu.getInt(1);
				idGrad.add(broj);
				Node node=new Node();
                                node.parent=-1;
                                node.rastojanje=(int)Double.POSITIVE_INFINITY;
                                mapaRastojanja.put(broj,node);
			}
		}
                catch (SQLException ex) {
                    Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
                }
        
		
                for(int id:idGrad){
			//ovde u hash mapu dodajemo za direktno povezane gradove rastojanja
			try(PreparedStatement upitLinija=conn.prepareStatement("SELECT PotrebnoDana FROM Linija where (IdG1=? and IdG2=?) or (IdG1=? and IdG2=?)")){ 
				upitLinija.setInt(1,idG);
				upitLinija.setInt(2,id);
				upitLinija.setInt(3,id);
				upitLinija.setInt(4,idG);
				
				ResultSet aa=upitLinija.executeQuery();
				if(aa.next()){ 
                                    Node node=mapaRastojanja.get(id);
                                    node.parent=idG;
                                    node.rastojanje=aa.getInt(1);
                                    mapaRastojanja.put(id,node);
                                }
			}
			catch (SQLException ex) {
				Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
			}
		} 
		
		for(int ii=0;ii<brGradova;ii++){ 
			int idd=imaMinRastojanje(mapaRastojanja,idGrad);
			int rastojanje=mapaRastojanja.get(idd).rastojanje;
                        idGrad.remove((Integer)idd);//da ne bi iduci put uzimao u obzir 
			for(int id:idGrad){
				
				int rastojanje2=mapaRastojanja.get(id).rastojanje;//rastojanje od naseg grada 
				try(PreparedStatement upitLinija=conn.prepareStatement("SELECT PotrebnoDana FROM Linija where (IdG1=? and IdG2=?) or (IdG1=? and IdG2=?)")){ 
					upitLinija.setInt(1,idd);
					upitLinija.setInt(2,id);
					upitLinija.setInt(3,id);
					upitLinija.setInt(4,idd);
					
					ResultSet aa=upitLinija.executeQuery();
                                        
                                        //ako postoji direktna grana sa prethodno uzetim gradom,preko koje se moze ostvariti 
                                        //manje rastojanje,pamti to rastojanje,ako i prethodni cvor kao roditelja
					if(aa.next()){
						int broj=aa.getInt(1);
						if(broj+rastojanje<rastojanje2){ 
							Node node=mapaRastojanja.get(id);
                                                        node.rastojanje=rastojanje+broj;
                                                        node.parent=idd;
                                                        mapaRastojanja.put(id,node);
						}
						
					}
				}
				catch (SQLException ex) {
					Logger.getLogger(ca200513_GeneralOperations.class.getName()).log(Level.SEVERE, null, ex);
				}
				
				
		}
                       
                }
		//treba vratiti samo one cvorove od id1 do IdG
                //tj.vratimo sve gradove na najmanjem rastojanju 
                List<Integer>idGradova=new ArrayList<>();
                Node node=mapaRastojanja.get(id1);
                idGradova.add(id1);
                
                while(node.parent!=idG){ 
                    idGradova.add(node.parent);
                    
                    node=mapaRastojanja.get(node.parent);
                }
                idGradova.add(idG);
               
                List<Integer>lista=new ArrayList<>();
                for(int i1=idGradova.size()-1;i1>=0;i1--){ 
                    lista.add(idGradova.get(i1));
                }
                return lista;
                
	}
        
	catch (SQLException ex) {
        Logger.getLogger(ca200513_OrderOperations.class.getName()).log(Level.SEVERE, null, ex);
    }

	return null;
    }
           
    private int imaMinRastojanje(HashMap<Integer,Node>rastojanja,List<Integer>gradovi){ 
            int min=(int)Double.POSITIVE_INFINITY;
            int idd=-1;
            for(int id:gradovi){ 
                    if(rastojanja.get(id).rastojanje<min){ 
                            min=rastojanja.get(id).rastojanje;
                            idd=id;
                    }
            }
            if(idd==-1 && !gradovi.isEmpty())idd=gradovi.get(0);
            return idd;
    }
}

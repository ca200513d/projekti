/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.etf.sab.student;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rs.etf.sab.operations.BuyerOperations;

/**
 *
 * @author user2
 */
public class ca200513_BuyerOperations implements BuyerOperations {

    
    Connection conn = DB.getInstance().getConnection();
    
    
    @Override
    public int createBuyer(String string, int i) {
        
          
          int id=-1;
          boolean flag=true;
          
          try(PreparedStatement upitKreiraj=conn.prepareStatement("INSERT INTO Kupac (IdG,Naziv)VALUES(?,?)");){ 
              
              upitKreiraj.setInt(1,i);
              upitKreiraj.setString(2,string);
              
              upitKreiraj.execute();
              
              try(PreparedStatement upitId=conn.prepareStatement("SELECT MAX(IdK) FROM Kupac");){ 
                  ResultSet idd=upitId.executeQuery();
                  if(idd.next()){ 
                      id=idd.getInt(1);
                      try(PreparedStatement upitDodaj=conn.prepareStatement("INSERT INTO RACUN (Iznos) VALUES(?)")){
                            upitDodaj.setBigDecimal(1, new BigDecimal(0));
                            upitDodaj.execute();
                            try(PreparedStatement upitDohvv=conn.prepareStatement("SELECT MAX(IdRac) FROM RACUN")){ 
                                ResultSet uu=upitDohvv.executeQuery();
                                if(uu.next()){ 
                                    int id1=uu.getInt(1);
                                        try(PreparedStatement upitD=conn.prepareStatement("INSERT INTO RACUNKUPAC(IdRac,IdK) VALUES(?,?)")){
                                            upitD.setInt(1,id1);
                                            upitD.setInt(2,id);
                                            upitD.execute();
                                        }
                                        catch(SQLException ex){ 
                                             Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                                        }
                                        }
                            }
                            catch(SQLException ex){ 
                                Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
                            }
                  
              }
              catch(SQLException ex){
                       flag=false;
               Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
          }
                 }}
              
          catch(SQLException ex){
              flag=false;
               Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
          }}
          catch(SQLException ex){
              flag=false;
               Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
          }
          if(!flag)return -1; //ako nije uspjelo dodavanje,vratri -1
          return id;
    }

    @Override
    public int setCity(int i, int i1) {
        boolean flag=true;
         try(PreparedStatement upitPostavi=conn.prepareStatement("UPDATE Kupac SET IdG=? WHERE IdK=?")){ 
             upitPostavi.setInt(1,i1);
             upitPostavi.setInt(2, i);
             
              upitPostavi.execute();
              
             
         }
         catch(SQLException ex){
               flag=false;
               Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
          }
         if(!flag)return -1;
         return 1;
    }

    @Override
    public int getCity(int i) {
      
      
      try(PreparedStatement upitGrad=conn.prepareStatement("SELECT IdG FROM Kupac WHERE IdK=?")){ 
          upitGrad.setInt(1, i);
          
          ResultSet gradovi=upitGrad.executeQuery();
          if(gradovi.next()){ 
              return gradovi.getInt(1);
          }
      }
      catch(SQLException ex){
               Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
      }
      
      return -1;
    }

    @Override
    public BigDecimal increaseCredit(int i, BigDecimal bd) {
       try(PreparedStatement upitIma=conn.prepareStatement("SELECT * FROM RACUNKUPAC WHERE IdK=?")){ 
          upitIma.setInt(1, i);
          ResultSet u=upitIma.executeQuery();
          if(u.next()){ 
            try(PreparedStatement upitDodaj=conn.prepareStatement("UPDATE Racun SET Iznos+=? WHERE IdRac=(SELECT IdRac FROM RacunKupac WHERE IdK=?)")){ 
            upitDodaj.setInt(2,i);
            upitDodaj.setBigDecimal(1, bd);
            upitDodaj.execute();
            }
            catch(SQLException ex){ 
            Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
             }
           }
          
       }
        catch(SQLException ex){ 
          Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
       }
          
            BigDecimal ret;
           
           try(PreparedStatement upitDohv=conn.prepareStatement("SELECT Iznos FROM Racun R,RacunKupac K WHERE K.IdRac=R.IdRac AND K.IdK=?")){
               upitDohv.setInt(1,i);
               ResultSet rez=upitDohv.executeQuery();
               if(rez.next()){ 
                   ret=rez.getBigDecimal(1);
                   return ret.setScale(3);
               }
           }
           catch(SQLException ex){ 
                Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);

           }
      
       return new BigDecimal(0).setScale(3);
    }

    @Override
    public int createOrder(int i) {
        try(PreparedStatement upitPorudzbina=conn.prepareStatement("INSERT INTO Porudzbina(IdK,Status,Vrijeme) VALUES(?,?,-1)")){ 
            upitPorudzbina.setInt(1,i);
            upitPorudzbina.setInt(2,0);//0 je kao created
          
            upitPorudzbina.execute();
            
            try(PreparedStatement upitId=conn.prepareStatement("SELECT MAX(IdPor) FROM PORUDZBINA");){ 
                  ResultSet idd=upitId.executeQuery();
                  if(idd.next()){ 
                      int id=idd.getInt(1);
                      return id;
                  }
                   
              }
              catch(SQLException ex){
               Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
          }
        }
        catch(SQLException ex){
               Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }

    @Override
    public List<Integer> getOrders(int i) {
        List<Integer> lista= new ArrayList<>();
        try(PreparedStatement upitPor=conn.prepareStatement("SELECT * FROM Porudzbina WHERE IdK=?")){ 
            upitPor.setInt(1, i);
            ResultSet rs=upitPor.executeQuery();
            
            while(rs.next()){ 
                lista.add(rs.getInt(1));
            }
        }
        catch(SQLException ex){
               Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
      }
        return lista;
    }

    @Override
    public BigDecimal getCredit(int i) {
       BigDecimal ret;
           
           try(PreparedStatement upitDohv=conn.prepareStatement("SELECT Iznos FROM Racun R,RacunKupac K WHERE K.IdRac=R.IdRac AND K.IdK=?")){
               upitDohv.setInt(1,i);
               ResultSet rez=upitDohv.executeQuery();
               if(rez.next()){ 
                   ret=rez.getBigDecimal(1);
                   return ret.setScale(3);
               }
           }
           catch(SQLException ex){
               Logger.getLogger(ca200513_BuyerOperations.class.getName()).log(Level.SEVERE, null, ex);
      }
        return new BigDecimal(0).setScale(3);
           
    }
}

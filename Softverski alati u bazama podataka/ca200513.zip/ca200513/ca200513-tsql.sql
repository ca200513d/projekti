SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create TRIGGER TR_TRANSFER_MONEY_TO_SHOPS
    ON [dbo].[Porudzbina]
    FOR UPDATE
    AS
    BEGIN
		DECLARE @S INT;
		SET @S=-1;
		DECLARE @S1 INT;
		set @s1=-1;
		declare @idPor int;
		set @idPor=-1;
		declare @vrijeme date;
		set @vrijeme='2001-01-01' ;
		declare @vrijeme2 date;
		set @vrijeme2 ='2001-01-01';
		DECLARE @IDK INT;
		set @idk=-1;

		DECLARE @cursorInsert CURSOR;
		set @cursorInsert = cursor FOR SELECT coalesce(Status,-1),coalesce(VrijemePoslata,'2001-01-01' ),coalesce(VrijemePrimljena,'2001-01-01' ),COALESCE(idPor,-1),COALESCE(IDk,-1) from inserted;

		declare @cursorDelete CURSOR; 
		set @cursorDelete = cursor FOR SELECT COALESCE(Status,-1) from Deleted;

		OPEN @cursorInsert;
		OPEN @cursorDelete; 

		FETCH NEXT FROM @cursorInsert INTO 
		@S,@vrijeme,@vrijeme2,@idPor,@IDk;

		FETCH NEXT FROM @cursorDelete INTO @S1;

		WHILE @@FETCH_STATUS = 0
		BEGIn  
			
				if(@S=1 and @s1=0 and @vrijeme<>'2001-01-01' )
				BEGIN 
				

					declare @CijenaKupac DECIMAL(10,3);
					exec dbo.SP_FINAL_PRICE @idPor,@vrijeme,@CijenaKupac output;

					declare @IdRac int;
					set @IdRac=(SELECT IdRac from RacunKupac R where r.idk=@idk);
					--DODAVANJE TRANSAKCIJE,GDJE KUPAC PLACA 
					INSERT INTO Transakcija(IdPor,Cena,IdRac,Vrijeme) VALUES(@idPor,@CijenaKupac,@IdRac,@vrijeme); 
					--skidanje novca sa racuna kupaca
					UPDATE Racun SET Iznos=iznos-@CijenaKupac WHERE IdRac=(SELECT RK.IdRac FROM RACUNKUPAC RK WHERE RK.IDK=@IDK); 

				END
			
				if(@S=3 and @s1<>3 and @vrijeme<>'2001-01-01' )
				BEGIN
					
					 INSERT INTO GRAD VALUES('GRAD1');
					--DAVANJE SISTEMU POTREBNI POSTOTAK

					
					IF((SELECT SUM(T.Cena) FROM Transakcija T JOIN Porudzbina P on P.IDPor=T.IdPor, Porudzbina P2 WHERE P2.IdK=P.IdK and P.Status=3 and P2.IdPor=@idPor and DATEADD(DAY, 30, P.VrijemePrimljena)<P2.VrijemePrimljena )>=10000)
					BEGIN 
						DECLARE @cijena2 DECIMAL(10,3);
						exec dbo.SP_FINAL_PRICE2 @idPor,@cijena2 output;
						set @cijena2=@cijena2*(3.00/100.00);
						IF(EXISTS(SELECT * FROM SISTEM WHERE IDS=1))
						BEGIN
							UPDATE SISTEM SET PROFIT+=@cijena2 WHERE IDS=1;
						END
						ELSE
						BEGIN 
							INSERT INTO SISTEM(ids,profit) values(1,@cijena2);
						END
					

				END

				ELSE
				BEGIN
					DECLARE @cijena3 DECIMAL(10,3);
					exec dbo.SP_FINAL_PRICE2 @idPor,@cijena3 output;
					set @cijena3=@cijena3*(5.00/100.00);
					IF(EXISTS(SELECT * FROM SISTEM WHERE IDS=1))
					BEGIN
						UPDATE Sistem SET PROFIT+=@cijena3 WHERE IDS=1;
					END
					ELSE
					BEGIN 
						INSERT INTO Sistem(ids,profit) values(1,@cijena3);
					END
				END

				--DODAVANJE TRANSAKCIJA,GDJE PRIMAJU PARE PRODAVCI
				DECLARE @myCursor cursor; 
				set @myCursor= cursor for
				select P.IDP,SUM((A.Cena-(A.Cena*coalesce(Iznos/100,0)))*S.Kolicina) FROM Artikal A JOIN Sadrzi S ON S.IdA=A.IdA,Prodavnica P LEFT JOIN POPUST PP ON PP.IDP=P.IDP WHERE S.IdPor=@idpor and A.IdP=P.IdP GROUP BY P.IdP;

				DECLARE @cijena DECIMAL(10,3); --cijena za 1 prodavnicu i sve narucene artikle iz nje ,sa uracunatim popustom
				DECLARE @idP int;
				
				
				OPEN @myCursor;

				FETCH NEXT FROM @myCursor 
				into @idP, @cijena;

				while @@FETCH_STATUS =0
				BEGIN
					SET @cijena=@cijena*95/100.00;
					UPDATE Racun SET Iznos=Iznos+@cijena WHERE IdRac=(SELECT RK.IdRac FROM RACUNPRODAVNICA RK where rk.idp=@idP);
					DECLARE @IdRac1 int;
					SET @IdRac1=(SELECT IdRac from RacunProdavnica WHERE IDP=@idP);
					INSERT INTO Transakcija VALUES(@idPor,@cijena,@IdRac1,@vrijeme2);

					FETCH NEXT FROM @myCursor 
					into @idP,@cijena;
				END

				CLOSE @myCursor;
				DEALLOCATE @myCursor;

				END
				


				
				FETCH NEXT FROM @cursorInsert INTO @S,@vrijeme,@vrijeme2,@idPor,@IDk;
				FETCH NEXT FROM @cursorDelete INTO @S1;
		END
		

		CLOSE @cursorInsert;
		CLOSE @cursorDelete;

		DEALLOCATE @cursorInsert;
		DEALLOCATE @cursorDelete;
		
END





create PROCEDURE dbo.SP_FINAL_PRICE
    @id int ,
	@currentDate date,
	@ukCijena decimal(10,3) output
AS
	
	SET @ukCijena=0;

    DECLARE @cijena DECIMAL(10,3);
	DECLARE @idP INT;
	DECLARE @kolicina INT;

	DECLARE myCursor CURSOR FOR
	(SELECT A.Cena,A.IdP,S.Kolicina 
	FROM Artikal A JOIN Sadrzi S ON A.IdA=S.IdA 
	WHERE S.IdPor=@id);
			

	OPEN myCursor;

	FETCH NEXT FROM myCursor INTO @cijena,@IdP,@kolicina;

	--sabiranje cijena i popusta za sve artikle
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF(EXISTS(SELECT Iznos FROM Popust WHERE IdP=@IdP))
		BEGIN 
			DECLARE @DecimalValue DECIMAL(10,3);
			SET @DecimalValue = CAST(@kolicina AS DECIMAL(10,3));

			declare @popust DECIMAL(10,3);
			set @popust=(SELECT Iznos FROM Popust WHERE IdP=@IdP);
			SET @ukCijena=@ukCijena+((@cijena-(@cijena*(@popust/100.00)))*@DecimalValue);
		END
		ELSE
		BEGIN
			DECLARE @DecimalValue1 DECIMAL(10,3);
			SET @DecimalValue1 = CAST(@kolicina AS DECIMAL(10,3));

			SET @ukCijena=@ukCijena+(@cijena*@DecimalValue1);
		END
		FETCH NEXT FROM myCursor INTO @cijena,@idP,@kolicina;
	END
	--da li treba smanjiti za 2%
	IF((SELECT SUM(T.Cena) FROM Transakcija T JOIN Porudzbina P on P.IDPor=T.IdPor, Porudzbina P2 WHERE P2.IdK=P.IdK and P.Status=3 and P2.IdPor=@id and DATEADD(DAY, 30, P.VrijemePrimljena) < @currentDate )>=10000)
	BEGIN 
		SET @ukCijena=@ukCijena-(@ukCijena*2/100.00);
	END
	CLOSE myCursor;
	DEALLOCATE myCursor;

RETURN @ukCijena;


CREATE PROCEDURE dbo.SP_FINAL_PRICE1
    @id int ,
	@ukCijena decimal(10,3) output
AS
    SET @ukCijena=0;

    DECLARE @cijena DECIMAL(10,3);
	DECLARE @kolicina INT;

	DECLARE myCursor CURSOR FOR
	(SELECT A.Cena,S.Kolicina 
	FROM Artikal A JOIN Sadrzi S ON A.IdA=S.IdA 
	WHERE S.IdPor=@id);
			

	OPEN myCursor;

	FETCH NEXT FROM myCursor INTO @cijena,@kolicina;

	--sabiranje cijena za sve artikle
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		SET @ukCijena=@ukCijena+(@cijena*@kolicina);
		
		FETCH NEXT FROM myCursor INTO @cijena,@kolicina;
	END
	
	CLOSE myCursor;
	DEALLOCATE myCursor;

RETURN @ukCijena;


CREATE PROCEDURE dbo.SP_FINAL_PRICE2
    @id int ,
	@ukCijena decimal(10,3) output
AS
	
	SET @ukCijena=0;

    DECLARE @cijena DECIMAL(10,3);
	DECLARE @idP INT;
	DECLARE @kolicina INT;

	DECLARE myCursor CURSOR FOR
	(SELECT A.Cena,A.IdP,S.Kolicina 
	FROM Artikal A JOIN Sadrzi S ON A.IdA=S.IdA 
	WHERE S.IdPor=@id);
			

	OPEN myCursor;

	FETCH NEXT FROM myCursor INTO @cijena,@IdP,@kolicina;

	--sabiranje cijena i popusta za sve artikle
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF(EXISTS(SELECT Iznos FROM Popust WHERE IdP=@IdP))
		BEGIN 
			declare @popust DECIMAL(10,3)
			set @popust=(SELECT Iznos FROM Popust WHERE IdP=@IdP);
			SET @ukCijena=@ukCijena+(@cijena-(@cijena*@popust/100))*@kolicina;
		END
		ELSE
		BEGIN
			SET @ukCijena=@ukCijena+(@cijena*@kolicina);
		END
		FETCH NEXT FROM myCursor INTO @cijena,@idP,@kolicina;
	END
	CLOSE myCursor;
	DEALLOCATE myCursor;

RETURN @ukCijena;


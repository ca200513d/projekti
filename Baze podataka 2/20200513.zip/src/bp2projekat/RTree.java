package bp2projekat;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class RTree {
	
	private Node root; //korijen stabla
	private int M; //gornja granica broja tacaka u 1 cvoru
	private int m; //donja granica broja tacaka u 1 cvoru 
	private int numOfNodes=1;
	private int level=0;//kolika je dubina stabla
	
	//klasa koja predstavlja tacku
	private class Point{ 
		private double x; 
		private double y;
		
		Point(double x,double y){ 
			this.x=x;
			this.y=y;
		}
	}
	
	private class Region{ 
		//granice(gornji lijevi ugao i donji desni ugao)
		private Point leftTop;
		private Point rightBottom;
		
		public Region(Point leftTop,Point rightBottom) { 
			this.leftTop=leftTop;
			this.rightBottom=rightBottom;
		}

	}
	
	//klasa koja predstavlja cvor
	private class Node{ 
		
		//podregioni,ako node nije list
		private ArrayList<Region>regions=new ArrayList<>();
		//tacke,ako je cvor list
		private ArrayList<Point>points=new ArrayList<>();
		//pokazivaci na dijecu 
		private ArrayList<Node>children=new ArrayList<>();
		//pokazivac na roditelja
		private Node parent=null;
		
		//za list
		public int insertPoint(Point p) { 
			points.add(p);
			return points.size();//vraca koliko je tacaka,ako je potrebno odraditi split
			
		}
		//za list
		public int deletePoint(Point p) { 
			points.remove(p);
			return points.size();//vraca koliko je tacaka,ako je potrebno odraditi split
		}
		
		
		//za sortiranje unutar 1 cvora
		//sortira se po x koordinati rastuce
		//po y koordinati opadajuce,da bi lijeva gornja i desna donja bile prva i poslednja
		//SAMO ZA LISTOVE!!!!
		public void sort() { 
			for(int i=0;i<points.size();i++) { 
				for(int j=i+1;j<points.size();j++) { 
					if(points.get(i).x>points.get(j).x) { 
						Point tmp=points.get(i);
						points.set(i,points.get(j));
						points.set(j,tmp);
						
						
					}
					else if(points.get(i).x==points.get(j).x && points.get(i).y<points.get(j).y) { 
						Point tmp=points.get(i);
						points.set(i,points.get(j));
						points.set(j,tmp);
						
					}
				}
			}
		}
		
		
	}

	public RTree(int m,int M) {
		
		root=new Node();
		this.m=m;
		this.M=M;
	}
	
	private ArrayList<Point> findMaxDistantPoints(Node node){
		
		ArrayList<Point> pair=new ArrayList<>();
		pair.add(new Point(0,0));//samo da bi bilo popunjeno
		pair.add(new Point(0,0));
		double maxDistance=Double.NEGATIVE_INFINITY; //najmanja moguca distanca
		
		for(int i=0;i<node.points.size()-1;i++) {
			Point point1=node.points.get(i);
			for(int j=i+1;j<node.points.size();j++) { 
				Point point2=node.points.get(j);
				double distance=Math.sqrt((point1.x-point2.x)*(point1.x-point2.x) + (point1.y-point2.y)*(point1.y-point2.y));
				if(distance>maxDistance) { 
					maxDistance=distance;
					pair.set(0,point1);
					pair.set(1,point2);
				}
			}
		}
		return pair;
	}
	
	private Point findMinDistance(Point p,Node node) { 
		double minDistance=Double.POSITIVE_INFINITY;
		Point min=null;
		for(Point point:node.points) { 
			double distance=Math.sqrt((p.x-point.x)*(p.x-point.x)+(p.y-point.y)*(p.y-point.y));
			if(distance<minDistance) { 
				minDistance=distance;
				min=point;
			}
		}
		return min;
	}
	private Region findRegion1(Node node) { 
		double minX=Double.POSITIVE_INFINITY;
		double maxX=Double.NEGATIVE_INFINITY;
		
		double minY=Double.POSITIVE_INFINITY;
		double maxY=Double.NEGATIVE_INFINITY;
		
		for(Point p:node.points) { 
			if(p.x<minX)minX=p.x;
			if(p.x>maxX)maxX=p.x;
			
			if(p.y<minY)minY=p.y;
			if(p.y>maxY)maxY=p.y;
		}
		
		return new Region(new Point(minX,maxY),new Point(maxX,minY));
	}
	
	private boolean splitLeaf(Node node) { 
		int ind1=-1;
		if(node.parent==null) { 
			node.parent=new Node();
			node.parent.children.add(node);
			numOfNodes++;
			root=node.parent;
			level++;
		}
		else {
			node.parent.regions.remove(node.parent.children.indexOf(node)); //izbaci stari region
		}
		ind1=node.parent.children.indexOf(node);
		ArrayList<Point>pair=findMaxDistantPoints(node);
		Point first=pair.get(0);
		Point second=pair.get(1);
		
		node.points.remove(first);
		node.points.remove(second);
		Node right=new Node();
		right.points.add(second);
		numOfNodes++;
		
		
		node.parent.children.add(ind1+1,right); //dodaj ga kao dijete roditelja
		right.parent=node.parent;
		
		Region region=null;
		
		while(right.points.size()<M/2+(M%2)) { //u desni cvor prebacimo m-1 tacku najblizu sa pair.get(1)
			Point p=findMinDistance(second,node);
			node.points.remove(p);
			right.points.add(p);
		}
		//dodaj 2 nova regiona
		node.points.add(0,first);
		node.sort();
		
		node.parent.regions.add(ind1,findRegion1(node));
		
		
		right.sort(); //da bi bile dobrim redmo tacke za topLeft i bottomRight
		region=findRegion1(right);
		node.parent.regions.add(ind1+1,region);
		
		
		if(node.parent.regions.size()==M+1)return true;
		return false;
		
		
	}
	private double distance(Region r1,Region r2) { 
		
		double R1CenterX=r1.leftTop.x + (r1.rightBottom.x - r1.leftTop.x)/2.0;
		double R1CenterY=r1.leftTop.y + (r1.rightBottom.y - r1.leftTop.y)/2.0;
		double R2CenterX=r2.leftTop.x + (r2.rightBottom.x - r2.leftTop.x)/2.0;
		double R2CenterY=r2.leftTop.y + (r2.rightBottom.y - r2.leftTop.y)/2.0;
		
		double distance=Math.sqrt((R2CenterX-R1CenterX)*(R2CenterX-R1CenterX)+ (R2CenterY-R1CenterY)*(R2CenterY-R1CenterY));
		
		return distance;
	}
	private ArrayList<Region> findMaxDistantRegions(Node node){ 
	
		ArrayList<Region> pair=new ArrayList<>();
		pair.add(new Region(new Point(0,0),new Point(0,0)));//samo da bi bilo popunjeno
		pair.add(new Region(new Point(0,0),new Point(0,0)));//samo da bi bilo popunjeno
		double maxDistance=Double.NEGATIVE_INFINITY; //najmanja moguca distanca
		
		for(int i=0;i<node.regions.size()-1;i++) {
			Region r=node.regions.get(i);
			for(int j=i+1;j<node.regions.size();j++) { 
				Region reg=node.regions.get(j);
				double distance=distance(r,reg);
				if(distance>maxDistance) { 
					maxDistance=distance;
					pair.set(0,r);
					pair.set(1,reg);
				}
			}
		}
		return pair;

		
	}
	private Region findRegion(Node node) { 
		double minX=Double.POSITIVE_INFINITY;
		double minY=Double.POSITIVE_INFINITY;
		
		double maxX=Double.NEGATIVE_INFINITY;
		double maxY=Double.NEGATIVE_INFINITY;
		
		for(Region r:node.regions) { 
			Point left=r.leftTop;
			Point right=r.rightBottom;
			
			if(left.x<minX)minX=left.x;
			if(right.x>maxX)maxX=right.x;
			if(left.y>maxY)maxY=left.y;
			if(right.y<minY)minY=right.y;
		}
		
		return new Region(new Point(minX,maxY),new Point(maxX,minY));
	}
	private Region findMinDistance2(Region r,Node node) {
		double minDistanceX=Double.POSITIVE_INFINITY;
		double minDistanceY=Double.POSITIVE_INFINITY;
		double minDistance=Double.POSITIVE_INFINITY;
		Region min=null;
		for(Region reg:node.regions) { 
			double distance=distance(r,reg);
			if(distance<minDistance) { 
				minDistance=distance;
				min=reg;
			}
		}
		return min;
	}
	private boolean splitInside(Node node) { 
		if(node.parent==null) { //ako se treba prelomiti root treba se dodati 2 nova covra
			node.parent=new Node();
			node.parent.children.add(node);
			numOfNodes++;
			root=node.parent;
			level++;
			
		}
		else {
			
			node.parent.regions.remove(node.parent.children.indexOf(node)); //izbaci stari region
		}
		int ind1=node.parent.children.indexOf(node);
		ArrayList<Region>pair=findMaxDistantRegions(node);
		Region first=pair.get(0);
		Region second=pair.get(1);
		
		Node right=new Node();
		node.parent.children.add(ind1+1,right);
		right.parent=node.parent;
		
		Node firstChild=node.children.get(node.regions.indexOf(first));
		Node secondChild=node.children.get(node.regions.indexOf(second));
		
		node.regions.remove(first);
		node.regions.remove(second);
		
		node.children.remove(firstChild);
		node.children.remove(secondChild);
		secondChild.parent=right;
		
		while(right.regions.size()!=M/2+(M%2)-1) { 
			Region r=findMinDistance2(second,node);
			int index=node.regions.indexOf(r);
			node.regions.remove(r);
			right.regions.add(r);
			node.children.get(index).parent=right;
			right.children.add(node.children.get(index));
			node.children.remove(index);
		}
		numOfNodes++;
		right.regions.add(second);
		right.children.add(secondChild);
		node.regions.add(0,first);
		node.children.add(0,firstChild);
		
		node.parent.regions.add(ind1,findRegion(node));
		node.parent.regions.add(ind1+1,findRegion(right));
		
		if(node.parent.regions.size()==M+1)return true;
		return false;
	}
	//kvadratni algoritam (krece od korijena i spusta se na nize
	public void split(Node node) { 
		boolean flag=true;
		boolean leaf=true;
		while(flag && node!=null) { 
			if(leaf) { 
				leaf=false;
				flag=splitLeaf(node);
				node=node.parent;
				
			}
			else { 
				flag=splitInside(node);
				node=node.parent;
				
			}
			
		}
		
	}
	//INSERT SAMO U LISTOVE!!!
	public void insert(double x,double y) { 
		Point p=new Point(x,y);
		
		//bira se region kome su gornja lijeva ili donja desna
		//na najmanjoj razdaljini od date tacke,pa se ide u njegovo podstablo ... dok ne dodjemo do lista
		//u koji cemo ubaciti tacku
		Node addPoint=minDistance(p);
		
		
		int num=addPoint.insertPoint(p);
		addPoint.sort();
		if(num==M+1) { 
			split(addPoint);
		}
	}
	
	private Node minDistance(Point p) { 
		
		Node node=root;
		while(node.children.size()!=0) { 
			boolean flag=false;
			for(Region r:node.regions) { 
				if(r.leftTop.x<=p.x && r.rightBottom.x>=p.x && r.leftTop.y>=p.y && r.rightBottom.y<=p.y) { 
					flag=true;
					node=node.children.get(node.regions.indexOf(r));
					break;
				}
			}
			if(flag)continue;
			else { 
				//najmanja distanca tacke od gornje lijeve ivice
				double minDistance1=Math.sqrt((node.regions.get(0).leftTop.x-p.x)*(node.regions.get(0).leftTop.x-p.x) + (node.regions.get(0).leftTop.y-p.y)*(node.regions.get(0).leftTop.y-p.y));
				Region min1=node.regions.get(0);
				
				for(Region r:node.regions){ 
					if(Math.sqrt((r.leftTop.x-p.x)*(r.leftTop.x-p.x) + (r.leftTop.y-p.y)*(r.leftTop.y-p.y))<minDistance1) { 
						minDistance1=Math.sqrt((r.leftTop.x-p.x)*(r.leftTop.x-p.x) + (r.leftTop.y-p.y)*(r.leftTop.y-p.y));
						min1=r;
					}
				}
			
				//najmanja distanca tacke od donje desne ivice
				double minDistance2=Math.sqrt((node.regions.get(0).rightBottom.x-p.x)*(node.regions.get(0).rightBottom.x-p.x) + (node.regions.get(0).rightBottom.y-p.y)*(node.regions.get(0).rightBottom.y-p.y));
				Region min2=node.regions.get(0);
				
				for(Region r:node.regions){ 
					if(Math.sqrt((r.rightBottom.x-p.x)*(r.rightBottom.x-p.x) + (r.rightBottom.y-p.y)*(r.rightBottom.y-p.y))<minDistance2) { 
						minDistance2=Math.sqrt((r.rightBottom.x-p.x)*(r.rightBottom.x-p.x) + (r.rightBottom.y-p.y)*(r.rightBottom.y-p.y));
						min2=r;
					}
				}
				//koje rastojanje je najmanje
				if(minDistance2<minDistance1) { 
					//pomjeranje granica,da bi obuhvatli i ovu tacku
					if(p.x>min2.rightBottom.x) { 
						min2.rightBottom.x=p.x;
					}
					if(p.y<min2.rightBottom.y) { 
						min2.rightBottom.y=p.y;
					}
					node=node.children.get(node.regions.indexOf(min2)); //dohvati lijevo podstablo
					
				}
				else {
					//pomjeranje granica,da bi obuhvatli i ovu tacku
					if(p.x<min1.leftTop.x) { 
						min1.leftTop.x=p.x;
					}
					if(p.y>min1.leftTop.y) { 
						min1.leftTop.y=p.y;
					}
					node=node.children.get(node.regions.indexOf(min1)); //dohvati lijevo podstablo
				}
				
				
			}
		}
		return node;
		
	}
	public ArrayList<Point> search(Region r){
		
		Node node=root;
		return searchPom(node,r);
		
	}
	
	private  ArrayList<Point> searchPom(Node node,Region r) { 
		ArrayList<Point>results=null;
				
		if(node.children.size()!=0){ 
			//ako je node unutrasnji cvor,za svaki region provjeri da li se poklapa sa zadatim i idi u postabla
			
			for(Region reg:node.regions) { 
				if(topLeft(r,reg) || downRight(r,reg) || topRight(r,reg) || downLeft(r,reg)
				 || topLeft(reg,r) || downRight(reg,r) || topRight(reg,r) || downLeft(reg,r)) { 
					if(results==null)results=new ArrayList<>();

					//samo lijevo podstablo treba obici
					Node left=node.children.get(node.regions.indexOf(reg));
					
				    ArrayList<Point>l=searchPom(left,r);
				    
				    if(l!=null) { 
				    	for(Point p:l){ 
					    	results.add(p);
					    }
				    }
					
				}
			}
			
		}
		else if(node.children.size()==0) { 
			//ako je node list,ispitaj svaku tacku unutar lista
			for(Point p:node.points) { 
				if(p.x>=r.leftTop.x && p.x<=r.rightBottom.x && p.y<=r.leftTop.y && p.y>=r.rightBottom.y) { 
					if(results==null)results=new ArrayList<>();
					results.add(p);
				}
			}
		}
		
		return results;
	}

	
	private boolean topLeft(Region reg,Region r) { 
		boolean ret=reg.leftTop.x>=r.leftTop.x && reg.leftTop.x<=r.rightBottom.x && reg.leftTop.y<=r.leftTop.y && reg.leftTop.y>=r.rightBottom.y;
		return ret;
	}
	private boolean downRight(Region reg,Region r) { 
		boolean ret=reg.rightBottom.x>=r.leftTop.x && reg.rightBottom.x<=r.rightBottom.x && reg.rightBottom.y<=r.leftTop.y && reg.rightBottom.y>=r.rightBottom.y;
		return ret;
	}
	private boolean downLeft(Region reg,Region r) { 
		boolean ret= reg.leftTop.x>=r.leftTop.x && reg.leftTop.x<=r.rightBottom.x && reg.rightBottom.y<=r.leftTop.y && reg.rightBottom.y>=r.rightBottom.y;
		return ret;
	}
	private boolean topRight(Region reg,Region r) { 
		boolean ret=reg.rightBottom.x>=r.leftTop.x && reg.rightBottom.x<=r.rightBottom.x && reg.leftTop.y<=r.leftTop.y && reg.leftTop.y>=r.rightBottom.y;
		return ret;
	}
	
	public void printTree(Node x,boolean[] flag,int depth, boolean isLast ){
		
		    if (x == null) { 
		    	System.out.println("Stablo je prazno!");
		    	return;
		    }
		     
		    for (int i = 1; i < depth; ++i) {
		         
		        if (flag[i] == true) {
		            System.out.print("| "
		               + " "
		               + " "
		               + " ");
		        }
		         
		        else {
		            System.out.print(" "
		               + " "
		               + " "
		               + " ");
		        }
		    }
		     
		    if (depth == 0) { 
		    	
		    	if(x.regions.size()>0) { 
		    		Region r1=x.regions.get(x.regions.size()-1);
		    		for(Region r:x.regions) { 
			    		if(r!=r1)System.out.print("L("+r.leftTop.x+" ,"+r.leftTop.y+") "
			    				+ " R("+r.rightBottom.x+" ,"+r.rightBottom.y+") | ");
			    		else System.out.print("L("+r.leftTop.x+" ,"+r.leftTop.y+") "
			    				+ " R("+r.rightBottom.x+" ,"+r.rightBottom.y+") ");
			    	}
		    	}
		    	else {
		    		Point p1=x.points.get(x.points.size()-1);
		    		for(Point p:x.points) { 
			    		if(p!=p1)System.out.print("("+p.x+" ,"+p.y+"), ");
			    		else System.out.print("("+p.x+" ,"+p.y+")");
			    	}
		    	}
		    }
		     
		    else if (isLast) {
		    	System.out.print("+--- ");
		    	if(x.regions.size()>0) { 
		    		Region r1=x.regions.get(x.regions.size()-1);
		    		for(Region r:x.regions) { 
			    		if(r!=r1)System.out.print("L("+r.leftTop.x+" ,"+r.leftTop.y+") "
			    				+ " R("+r.rightBottom.x+" ,"+r.rightBottom.y+") | ");
			    		else System.out.print("L("+r.leftTop.x+" ,"+r.leftTop.y+") "
			    				+ " R("+r.rightBottom.x+" ,"+r.rightBottom.y+") ");
			    	}
		    	}
		    	else {
		    		Point p1=x.points.get(x.points.size()-1);
		    		for(Point p:x.points) { 
			    		if(p!=p1)System.out.print("("+p.x+" ,"+p.y+"), ");
			    		else System.out.print("("+p.x+" ,"+p.y+")");
			    	}
		    	}
		        flag[depth] = false;
		    }
		    else {
		    	System.out.print("+--- ");
		    	if(x.regions.size()>0) { 
		    		Region r1=x.regions.get(x.regions.size()-1);
		    		for(Region r:x.regions) { 
			    		if(r!=r1)System.out.print("L("+r.leftTop.x+" ,"+r.leftTop.y+") "
			    				+ " R("+r.rightBottom.x+" ,"+r.rightBottom.y+") | ");
			    		else System.out.print("L("+r.leftTop.x+" ,"+r.leftTop.y+") "
			    				+ " R("+r.rightBottom.x+" ,"+r.rightBottom.y+") ");
			    	}
		    	}
		    	else {
		    		Point p1=x.points.get(x.points.size()-1);
		    		for(Point p:x.points) { 
			    		if(p!=p1)System.out.print("("+p.x+" ,"+p.y+"), ");
			    		else System.out.print("("+p.x+" ,"+p.y+")");
			    	}
		    	}
		    }
		 
		    int it = 0;
		    System.out.print("\n");
		    flag[depth] = true;
		    for (Node i : x.children) {
		         ++it;
		        printTree(i, flag, depth + 1,
		            it == (x.children.size()) - 1);
		    }
		    
	}
	
	public Point getPoint(double x,double y) { 
		return new Point(x,y);
	}
	public Region getRegion(Point p1,Point p2) {
		return new Region(p1,p2);
	}
	public void printPom(int depth) { 
		printDepth(root,depth);
	}
	public void printDepth(Node node,int depth) { 
		if(depth<0 || depth>level) { 
			System.out.println("Nekorektan unos dubine!");
			return;
		}
		int level=0;
		
		if(depth==0) { 
			if(node.children.size()!=0) { //ako nije u pitanju list
				Region r1=node.regions.get(node.regions.size()-1);
	    		for(Region r:node.regions) { 
		    		if(r!=r1)System.out.print("L("+r.leftTop.x+" ,"+r.leftTop.y+") "
		    				+ " R("+r.rightBottom.x+" ,"+r.rightBottom.y+") | ");
		    		else System.out.print("L("+r.leftTop.x+" ,"+r.leftTop.y+") "
		    				+ " R("+r.rightBottom.x+" ,"+r.rightBottom.y+") ");
		    	}
	    		System.out.println(" ");
			}
			else { 
				Point p1=node.points.get(node.points.size()-1);
	    		for(Point p:node.points) { 
		    		if(p!=p1)System.out.print("("+p.x+" ,"+p.y+"), ");
		    		else System.out.print("("+p.x+" ,"+p.y+")");
		    	}
	    		System.out.println(" ");
			}
		}
		else { 
			depth--;
			for(Node child:node.children) { 
				printDepth(child,depth);
			}
		}
	}
	
	public static void main(String[] args) {
		
		RTree rt=null;
		
		Scanner scanner = new Scanner(System.in);

		System.out.println("MENI:\n 1)Kreiraj stablo. \n"
				+ " 2)Ubaci tacke iz fajla. \n"
				+ " 3)Ubaci novu tacku. \n"
				+ " 4)Pretrazi region. \n"
				+ " 5)Obrisi stablo. \n"
				+ " 6)Prikazi stablo. \n"
				+ " 7)Prikazi nivo. \n"
				+ " 0)KRAJ RADA.");
		while(true) { 
			System.out.println("Unesite izbor: ");
			try {
				int in=scanner.nextInt();
				switch(in) { 
				case 0: return;
				case 1: System.out.println("Unesite gornju granicu: ");
						int M=scanner.nextInt();
						System.out.println("Unesite donju granicu: ");
						int m=scanner.nextInt();
						if(M<m || m<0 || M<0 || (int) Math.ceil(M / 2.0)<m) {
							System.out.println("Greska pri unosu!");
							continue;
						}
						else rt=new RTree(m,M);
						break;
						
				case 2:
					String filePath = "points.txt";
					while(true){ 
						 System.out.println("Unesite gornju granicu: ");
							int Mm=scanner.nextInt();
							System.out.println("Unesite donju granicu: ");
							int mm=scanner.nextInt();
							if(Mm<mm || mm<0 || Mm<0 || (int) Math.ceil(Mm / 2.0)<mm) {
								System.out.println("Greska pri unosu!");
								continue;
							}
							else { 
								rt=new RTree(mm,Mm);
								break;
							}
					}
			        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
			            String line;
			            while ((line = reader.readLine()) != null) {
			                String[] coords=line.split(",");
			                double x=Double.parseDouble(coords[0]);
			                double y=Double.parseDouble(coords[1]); 
			                rt.insert(x, y);
			            }
			        } catch (IOException e) {
			            e.printStackTrace();
			        }
			        break;
				case 3: if(rt==null) { 
							System.out.println("Stablo nije kreirano!");
							break;
						}
						System.out.println("Unesite x koordinatu:");
						double x=scanner.nextDouble();
						System.out.println("Unesite y koordinatu:");
						double y=scanner.nextDouble();
						rt.insert(x,y);
						break;
				case 4: if(rt==null) { 
							System.out.println("Stablo nije kreirano!");
								break;
						}
						System.out.println("Unesite x koordinatu za gornju lijevu tacku:");
						double xL=scanner.nextDouble();
						System.out.println("Unesite y koordinatu za gornju lijevu tacku:");
						double yL=scanner.nextDouble();
						
						System.out.println("Unesite x koordinatu za donju desnu tacku:");
						double xR=scanner.nextDouble();
						System.out.println("Unesite y koordinatu za donju desnu tacku:");
						double yR=scanner.nextDouble();
						
						Region r=rt.getRegion(rt.getPoint(xL,yL),rt.getPoint(xR, yR));
						
						ArrayList<Point>results=rt.search(r);
						
						if(results!=null && results.size()>0) { 

							for(Point p:results) { 
								System.out.println("Point:("+p.x+" ,"+p.y+")");
							}
						}
						else { 
							System.out.println("Ne postoji zajednicka tacka!");
						}
						
						break;
				case 5:if(rt==null) { 
						System.out.println("Stablo nije kreirano!");
						break;
					}
				else rt=null;break;
				
				
				case 6:
						int nv=rt.numOfNodes;
					
						boolean[] flag = new boolean[nv];
					    Arrays.fill(flag, true);
						rt.printTree(rt.root, flag, 0, false);
						break;
						
				case 7:System.out.println("Unesite dubinu stabla: ");
					int depth=scanner.nextInt();
					rt.printPom(depth);
					break;
				
				default:System.out.println("Ne postoji opcija!Pokusajte ponovo!");
						continue;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return;
			}
		}
		
	}
		

}

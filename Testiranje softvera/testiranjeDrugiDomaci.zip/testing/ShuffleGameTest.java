package testing;
import shuff.AnimatedJButton;
import shuff.Credits;
import shuff.SecondsCounter;
import shuff.ShuffleGame;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;

import javax.swing.Timer;

import javax.swing.JButton;
import javax.swing.JMenuItem;

import org.junit.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.mockito.Mockito;






public class ShuffleGameTest {
	

	private ShuffleGame gameOriginal=new ShuffleGame(3);
	
	//pokretanje secondCounter
	@Test
	public void testPokreniSecondCounter() { 
		
	     ShuffleGame game=new ShuffleGame(4);
		 game.startSecondsCounter();
		 
		 SecondsCounter sc=game.getSecondsCounter();
		int t= sc.getTime();
		
		assertEquals(0,t);
	}
	
	
	//stanje dugmeta
	@Test
	public void testStateButton() { 
		
		ShuffleGame game=new ShuffleGame(5);
		game.changeButtonState(false);
		String text=game.getButtonState();
		
		assertEquals("Zzzz....",text);
		
		game.changeButtonState(true);
		
		text=game.getButtonState();
		
		assertNotEquals("Zzzz....",text);
	}
	
	
	
	//za mis kod pauze,jer ne prodje kroz te metode
	@Test
	public void mouseTest() { 
		
		ShuffleGame.run(3); 
		Robot r;
		try {
			r = new Robot();
			
			r.mouseMove(350, 350);
			r.mousePress(InputEvent.BUTTON1_DOWN_MASK);
			r.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
			
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		boolean status=ShuffleGame.getGame().getGameStatus();
		
		assertFalse(status);
		
		
	}
	
	 //instrukcije 
	private void testInstrukcije(ShuffleGame game) { 
    	
		ActionEvent e=new ActionEvent("Instructions",1,"Instructions");
		game.actionPerformed(e);
	}
	//about shuffle
	private void testAboutShuffle(ShuffleGame game) { 
      
    	ActionEvent e=new ActionEvent("About Shuffle",1,"About Shuffle");
		game.actionPerformed(e);
   	  
   	  
		
	}
	//high score
    
	private void testHighScore(ShuffleGame game) { 
		ActionEvent e=new ActionEvent("High Scores",1,"High Scores");
		game.actionPerformed(e);
		
	}
	
	

	//pokretanje nove igre
	private ShuffleGame testPokretanjeNoveIgre(ShuffleGame game) { 
		
		ActionEvent e=new ActionEvent("level5",1,"level5");
		game.actionPerformed(e);
		
		int lvl=ShuffleGame.getGame().getLevel();
		
		assertEquals(8,lvl);//jer pise u app da je i=0 == 3,pa ako je zadato 5 bice nivo 8
		
		
		return ShuffleGame.getGame();
		
	}
	//gasenje igre
	private void testGasenjeIgre(ShuffleGame game) { 
		ActionEvent e1=new ActionEvent("CLOSE",1,"CLOSE");
		game.actionPerformed(e1);
		
		SecondsCounter sc=game.getSecondsCounter();
		Timer timer=sc.getTimer();
		
		assertNull(timer);
		
	}
	//restartovanje igre
	private ShuffleGame testRestartuj(ShuffleGame game) { 
		
		
		ActionEvent e1=new ActionEvent("ReStart",1,"ReStart");
		game.actionPerformed(e1);
		
		boolean status=game.getGameStatus();
		
		assertFalse(status);
		
		boolean status1=ShuffleGame.getGame().getGameStatus();
		
		assertFalse(status1);
		
		return ShuffleGame.getGame();
	}
	
	
	//pokretanje igre,ako nema vec postojece
	@Test 
	public void testPokretanjeIgre() { 
		ShuffleGame.run(6);
		ShuffleGame game=ShuffleGame.getGame();
		
		assertNotNull(game);
	}
	
	//actionPerformedTest

	@Test
	public void actionPerformedTest() { 
		ShuffleGame game=new ShuffleGame(3);
		testHighScore(game);
		testInstrukcije(game);
		testAboutShuffle(game);
		game=testRestartuj(game);
		game=testPokretanjeNoveIgre(game);
		testGasenjeIgre(game);
		
	}
	//za restartovanje brojaca sekundi
    @Test 
    public void testRestartSecondsCounter() { 
    	ShuffleGame game=new ShuffleGame(3);
    	SecondsCounter sc=game.getSecondsCounter();
    	sc.reStart();
		int t= sc.getTime();
		
		assertEquals(0,t);
    }
    
    //za dohvatanje  proteklog vremena kao stringa
    @Test
    public void testTimeElapsed() { 
    	ShuffleGame game=new ShuffleGame(3);
    	SecondsCounter sc=game.getSecondsCounter();
    	String s=sc.getTimeElapsed();
    	assertNotNull(s); 
    }
    
    //za dohvatanje proteklog vremena u sekundama
	@Test 
	public void testGetTimeElapsed2() { 
		ShuffleGame game=new ShuffleGame(3);
		SecondsCounter sc=game.getSecondsCounter();
    	int br=sc.getTimeElapsedInSeconds();
    	assertEquals(0,br);
	}
	
	
	
	//prikaz warning dijaloga
	@Test
	public void testShowWarning() { 
		ShuffleGame game=new ShuffleGame(3);
		
		game.showWarrningDialog();
	}
	//dohvatanje vremena od credits
	@Test
	public void testTimeInSeconds() { 
		
		Credits credits=new Credits(20,20,20);
		int br=credits.getTimeInSeconds();
		
		assertEquals(20,br);
		
	}
	
	//poredjenje 
	@Test 
	public void testCompare() { 
		Credits credits=new Credits(20,20,20);
	    int rezultat=credits.compare(0.3, 4.3);
	    
	    assertEquals(-1,rezultat);
	}
	
	
	//odigraj igricu,pritisak dugmeta sa brojem i kraj igre 
	@Test
	public void odigrajIgru() { 
		ShuffleGame game=new ShuffleGame(3);
		int matrix[]={1,2,3,4,5,6,7,0,8};
		JButton[] buttons= {new JButton(String.valueOf( ( matrix[0] ) ) ),new JButton(String.valueOf( ( matrix[1] ) ) ),new JButton(String.valueOf( ( matrix[2] ) ) ),new JButton(String.valueOf( ( matrix[3] ) ) ),new JButton(String.valueOf( ( matrix[4] ) ) ),new JButton(String.valueOf( ( matrix[5] ) ) ),new JButton(String.valueOf( ( matrix[6] ) ) ),null,new JButton(String.valueOf( ( matrix[8] ) ) )};
		for(int i=0;i<buttons.length;i++) { 
			if(buttons[i]!=null) {
				buttons[i].addActionListener( game ) ;
	            buttons[i].setActionCommand( "number" ) ;
			}
		}
		game.setMatrix(matrix,buttons);
		
		buttons=game.getButtonA();
	    
		buttons[8].doClick();
		
		boolean end=game.getGameStatus();
		
		assertFalse(end);//da li je kraj igre
		
		
	}
	
//MOCKITO TESTOVI
	//pritisni pauzu i pokreni ponovo
		@Test
		public void testPause() { 
			
			
			AnimatedJButton pause=mock(AnimatedJButton.class);
			ActionEvent e=new ActionEvent(pause,1,"PAUSE");
			gameOriginal.actionPerformed(e);
			boolean status=gameOriginal.getGameStatus();
			
			doNothing().when(pause).setLabelName( "start" ) ;
	        doNothing().when(pause).setActionCommand("start");
	        
	        pause.setLabelName("start");
	        pause.setActionCommand("start");
	        
	        
	        verify(pause).setLabelName("start");
	        verify(pause).setActionCommand("start");
			
			assertFalse(status);
		
		}
		
		@Test 
		public void testStart() { 
			AnimatedJButton start=mock(AnimatedJButton.class);
			ActionEvent e1=new ActionEvent(start,1,"START");
			gameOriginal.actionPerformed(e1);
			
			boolean status=gameOriginal.getGameStatus();
			doNothing().when(start).setLabelName( "pause" ) ;
	        doNothing().when(start).setActionCommand("pause");
	        
	        start.setLabelName("pause");
	        start.setActionCommand("pause");
	        
	        
	        verify(start).setLabelName("pause");
	        verify(start).setActionCommand("pause");
			
			assertTrue(status);
		}
		
		//za pritiskanje dugmeta AnimatedButton actionPerformed
		
		@Test
		public void testAnimatedButtonAction() { 
			
			AnimatedJButton dugme=new AnimatedJButton("dugme",1);
			
			ActionEvent e=mock(ActionEvent.class);
			
			dugme.actionPerformed(e);
			
			String str=dugme.getString("dugme",2);
			
			assertEquals("d  u  g  m  e",str);
		}
		
//PARAMETRIZOVANI TESOTVI
	
	//kreiranje tabele zadate velicine i pravljenje zadataog broja koraka nad tabelom
	@ParameterizedTest
	@CsvFileSource(resources={"/ulaz1.csv"})
	public void testVelicinaTable(int level,int moves) { 
		
		ShuffleGame.run(level);
		ShuffleGame game=ShuffleGame.getGame();
		
	    JButton buttons[]=game.getButtonA();
	    int length=buttons.length;
	    int copyMoves=moves;
	    while(moves>0) {
		    for(int i=0;i<length;i++) { 
		    	if(buttons[i]!=null) { 
		    		int blk1=game.getBlank();
		    		buttons[i].doClick();
		    		int blk2=game.getBlank();
		    		if(blk1!=blk2) {
		    			moves--;
				    	if(moves<=0)break;
		    		}
		    	}
		    	
		    }
		   
		}
	    int moves2=game.getMoves();
	    assertEquals(moves2,copyMoves);
	}
	
	//pronalazenje pozicije zadatog dugmeta,na tabli zadate velicine
	@ParameterizedTest
	@CsvFileSource(resources={"/ulaz2.csv"})
	public void pronadjiPoziciju(int level,int broj) { 
		ShuffleGame game=new ShuffleGame(3);
		
		int pos=game.getPosition(broj);
		
		JButton buttons[]=game.getButtonA();
		
		
		
		int pos1=0;
		for(int i=0;i<buttons.length;i++) { 
			if(buttons[i]!=null && Integer.parseInt(buttons[i].getText())==broj) { 
				pos1=i;
			}
		}
		assertEquals(pos1,pos);
	}
	


	
	
	


}
